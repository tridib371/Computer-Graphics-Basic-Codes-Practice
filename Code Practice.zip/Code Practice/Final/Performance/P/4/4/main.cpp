#include <windows.h>
#include <GL/glut.h>

float scalingFactor = 1.0f; // Initial scaling factor

// Function to animate the zoom in and out effect
void animateZoom(int value) {
    // Change the scaling factor to zoom in and out
    scalingFactor += 0.01f; // Increase scaling factor for zooming in

    // If the scaling factor exceeds 2, reset it to 1 for zooming out
    if (scalingFactor > 2.0f)
        scalingFactor = 1.0f;

    glutPostRedisplay(); // Mark the window for redisplay
    glutTimerFunc(20, animateZoom, 0); // Call the function again after 20 milliseconds
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Set up the viewport and projection matrix for scaling
    glViewport(0, 0, glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1.0 * scalingFactor, 1.0 * scalingFactor, -1.0 * scalingFactor, 1.0 * scalingFactor, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();


    // Draw a square as an example
    glColor3ub(25, 150, 10); // green color
    glBegin(GL_QUADS);
    glVertex2f(-0.5f, -0.5f);
    glVertex2f(0.5f, -0.5f);
    glVertex2f(0.5f, 0.5f);
    glVertex2f(-0.5f, 0.5f);
    glEnd();

    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Zoom In and Out Animation");
    glutDisplayFunc(display);
    glutTimerFunc(0, animateZoom, 0); // Start the zoom animation timer
    glutMainLoop();
    return 0;
}



