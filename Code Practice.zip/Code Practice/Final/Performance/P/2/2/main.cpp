#include <windows.h>
#include <GL/glut.h>
#include <stdlib.h>
#define MAX_RAIN_DROPS 500 // Adjust this value as needed

struct Raindrop {
    float x;
    float y;
    float speed;
};

Raindrop raindrops[MAX_RAIN_DROPS];
float riverWaterLevel = -0.6f; // Initial water level of the river
float groundWaterLevel = -1.0f; // Initial water level of the ground

// Initialize raindrops
void initRain() {
    for (int i = 0; i < MAX_RAIN_DROPS; ++i) {
        raindrops[i].x = ((float)rand() / RAND_MAX) * 2.0f - 1.0f; // Random x position
        raindrops[i].y = 1.0f; // Start from the top
        raindrops[i].speed = ((float)rand() / RAND_MAX) * 0.05f + 0.02f; // Random speed
    }
}

// Draw raindrops
void drawRain() {
    glColor3f(0.0f, 0.0f, 1.0f); // Blue color for raindrops

    glLineWidth(2.0f); // Set the line width for thicker raindrops

    glBegin(GL_LINES);
    for (int i = 0; i < MAX_RAIN_DROPS; ++i) {
        glVertex2f(raindrops[i].x, raindrops[i].y);
        glVertex2f(raindrops[i].x, raindrops[i].y - 0.03f); // Adjust the length of raindrops
    }
    glEnd();
}

// Update raindrops position
void updateRain() {
    for (int i = 0; i < MAX_RAIN_DROPS; ++i) {
        raindrops[i].y -= raindrops[i].speed; // Move raindrop downward

        // If raindrop reaches the bottom, reset its position to the top
        if (raindrops[i].y < -1.0f) {
            raindrops[i].y = 1.0f;
            raindrops[i].x = ((float)rand() / RAND_MAX) * 2.0f - 1.0f;
        }
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw ground
    glColor3ub(0, 102, 0); // Green color for ground
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, groundWaterLevel);
    glVertex2f(1.0f, groundWaterLevel);
    glVertex2f(1.0f, -1.0f);
    glVertex2f(-1.0f, -1.0f);
    glEnd();

    // Draw river
    glColor3ub(30, 144, 255); // Blue color for river
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -0.5f);
    glVertex2f(1.0f, -0.5f);
    glVertex2f(1.0f, riverWaterLevel); // Adjust Y-coordinate of river's lower boundary
    glVertex2f(-1.0f, riverWaterLevel); // Adjust Y-coordinate of river's lower boundary
    glEnd();

    // Draw rain
    drawRain();

    glFlush();
}

// Timer function to update raindrops position and flood effect
void timer(int value) {
    updateRain();

    // Increase river and ground water level while raining
    if (riverWaterLevel > -1.0f) {
        riverWaterLevel -= 0.0005f; // Adjust the rate at which river water level rises
        groundWaterLevel = riverWaterLevel;
    }

    glutPostRedisplay();
    glutTimerFunc(18, timer, 0); // Update at 60 frames per second
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("River, Ground, and Rain Scenario");
    glutDisplayFunc(display);
    initRain(); // Initialize raindrops
    glutTimerFunc(0, timer, 0); // Start the timer
    glutMainLoop();
    return 0;
}


