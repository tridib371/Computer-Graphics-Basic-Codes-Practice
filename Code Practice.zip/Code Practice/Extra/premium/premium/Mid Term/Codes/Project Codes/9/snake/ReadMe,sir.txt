Sir,

This project requires the newest version of Freeglut library. This will not run in Glut32

Sincerely,

Rifat Al Mahfuz
S.M. Sharier
Group9
CG [J]