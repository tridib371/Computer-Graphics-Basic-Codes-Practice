#include <windows.h>
#include <math.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <stdlib.h>
#define PI 3.14159265358979323846
#define MAX_RAIN_DROPS 500 // Adjust this value as needed

struct Raindrop {
    float x;
    float y;
    float speed;
};

Raindrop raindrops[MAX_RAIN_DROPS];

// Initialize raindrops
void initRain() {
    for (int i = 0; i < MAX_RAIN_DROPS; ++i) {
        raindrops[i].x = ((float)rand() / RAND_MAX) * 2.0f - 1.0f; // Random x position
        raindrops[i].y = 1.0f; // Start from the top
        raindrops[i].speed = ((float)rand() / RAND_MAX) * 0.02f + 0.01f; // Random speed
    }
}

// Draw raindrops
void drawRain() {
    glColor3f(0.0f, 0.0f, 1.0f); // Blue color for raindrops

    glLineWidth(4.0f); // Set the line width for thicker raindrops

    glBegin(GL_LINES);
    for (int i = 0; i < MAX_RAIN_DROPS; ++i) {
        glVertex2f(raindrops[i].x, raindrops[i].y);
        glVertex2f(raindrops[i].x, raindrops[i].y - 0.03f); // Adjust the length of raindrops
    }
    glEnd();
}

// Update raindrops position
void updateRain() {
    for (int i = 0; i < MAX_RAIN_DROPS; ++i) {
        raindrops[i].y -= raindrops[i].speed; // Move raindrop downward

        // If raindrop reaches the bottom, reset its position to the top
        if (raindrops[i].y < -1.0f) {
            raindrops[i].y = 1.0f;
            raindrops[i].x = ((float)rand() / RAND_MAX) * 2.0f - 1.0f;
        }
    }
}

// Display callback
void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawRain();

    glFlush();
}

// Timer function to update raindrops position
void timer(int value) {
    updateRain();
    glutPostRedisplay();
    glutTimerFunc(6, timer, 0); // Update at 60 frames per second
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Village Day Scene");
    glutDisplayFunc(display);
//    init();
    initRain(); // Initialize raindrops
    glutTimerFunc(0, timer, 0); // Start the timer
    glutMainLoop();
    return 0;
}

