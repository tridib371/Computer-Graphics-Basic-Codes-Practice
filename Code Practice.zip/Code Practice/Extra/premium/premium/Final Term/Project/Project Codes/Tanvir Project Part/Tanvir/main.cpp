#include <iostream>
#include<GL/gl.h>
#include <GL/glut.h>
#include <windows.h>
#include <math.h>
#include <mmsystem.h>
#define PI 3.141516

 float benchPosition = 0.0f;
    int benchSpeed = 45;
    float stopstart=0.01f;                                                                                                                                                                   //fro
    bool f= false;
    float cloudPosition=-1.0;
    float cloudSpeed=0.005;
    float sunPosition=-0.5;
    float sunSpeed=0.01;
    float ghostX = 0.0f;
    float ghostY = 0.0f;
    float ghostmovement = 0.001f;
    float ghostmovement3rd = 1.5f;
    float move_flow = 0.0f;
    float move_speed_boat =1.0f;
    float boatstartstop=0.5;
    float watermove =  0.05;
    float watermove2 = 0.053;
    float watermove3 = 0.048;
    float watermove4 = 0.047;
    float angle=0,bx=0.0,by=0.0;
    float angle_speed =0.0f;
    float bardspeed=0.02;
    float bardposition = 20;
    float trainmovent = 1.0f;
    float trainstartstop = 0.02f;
    int trainspeed = 35;
    float chairmove = 0.02f;
    float chairmove2 = 0.05f;
    float chairmove3 = 0.08f;
    float blackshipupdate= 1.0f;
    float blackshipstartstop = 0.0;
    float chairmovespeed = 0.0f;
    float chairmove2speed = 0.0f;
    bool fountainRunning = false;
    float centerX = 0.5f;
    float centerY = 0.5f;
    float angularFrequency = 0.1f;
    int rotationCount = 0;
    float translationSpeed = 0.0000005f; // Adjusted translation speed
    bool p = false;
    float glowAlpha = 0.0f; // Initial glow value
    bool isColorOn = false;  // Flag to indicate whether the circle color is on or off
    float speed = 0.02f;
    int resumeGhostMovement = 50;
    float speedMultiplier = 1.0f;    // Initial speed multiplier
    float scale = 1.0f; // Initial scale factor
    bool increasingScale = true; // Flag to control scale direction
    bool k = false;


void ground() //F19
{
    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad

    glColor3ub(51.0f, 102.0f, 0.0f); // Red
    glVertex2f(-1.0f, -1.0f);    // x, y
    glColor3ub(76.0f, 153.0f, 0.0f);
    glVertex2f(1.0f, -1.0f);    // x, y
    glColor3ub(76.0f, 153.0f, 0.0f); // Red
    glVertex2f(1.0f, -0.1f);    // x, y
    glColor3ub(102.0f, 204.0f, 0.0f); // Red
    glVertex2f(-1.0f, -0.1f);    // x, y




    glEnd();
}


void Ghost()//F37
{


    //Ghost Hat
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2f(-0.5324120085967, 0.4132103872745); //U22
    glVertex2f(-0.4727072133115, 0.4146601452409); //F23
    glVertex2f(-0.4645636637043, 0.4225128537907);//G23
    glVertex2f(-0.4299535778738, 0.4236762180203); //H23
    glVertex2f(-0.414829842889, 0.4318197676275); //l23
    glVertex2f(-0.4, 0.44); //J23
    glVertex2f(-0.3662849321763, 0.4365047130341);//E23
    glVertex2f(-0.3944944633464, 0.4512287122303); //D23
    glVertex2f(-0.4015367157788, 0.4512455791154); //C23
    glVertex2f(-0.4358439504053, 0.438275770903); //B23
    glVertex2f(-0.4723213381552, 0.449694008614);//A23
    glVertex2f(-0.4832902700612, 0.4492170985311); //Z22
    glVertex2f(-0.5030820385003, 0.4461171829924); //W22
    glVertex2f(-0.5202508014836, 0.4346713410036); //V22


    glEnd();


    //Ghost Face
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2f(-0.5355119241354, 0.4031952755342); //Q22
    glVertex2f(-0.4601691638938, 0.3730884872031); //S23
    glVertex2f(-0.4101763859706, 0.375396602492);//R23
    glVertex2f(-0.3915625582971 , 0.387030244788); //Q23
    glVertex2f(-0.407558816454, 0.3852851984436); //P23
    glVertex2f(-0.3866182603213, 0.4091341651503); //O23
    glVertex2f(-0.4, 0.4);//N23
    glVertex2f(-0.4171565713482, 0.3989547281414); //M23
    glVertex2f(-0.4107580680854, 0.4021539797727); //L23
    glVertex2f(-0.4407146969976, 0.4027356618875); //K23
    glVertex2f(-0.4727072133115, 0.4146601452409);//F23
    glVertex2f(-0.5324120085967, 0.4132103872745); //U22
    glEnd();

    //Ghost face down
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2f(-0.5355119241354, 0.4031952755342); //Q22
    glVertex2f(-0.5355119241354, 0.3919878885868); //P22
    glVertex2f(-0.5414733001712, 0.3853111474266);//O22
    glVertex2f(-0.5438578505856, 0.3733883953549); //N22
    glVertex2f(-0.531458188431 , 0.3795882264322); //M22
    glVertex2f(-0.5338427388453, 0.3707653898991); //L22
    glVertex2f(-0.5309812783481, 0.3669501092362);//K22
    glVertex2f(-0.5347391611688, 0.3602242211769); //H22
    glVertex2f(-0.5249995708677, 0.3576111603644); //J22
    glVertex2f(-0.5169228374474, 0.3609368741258); //l22
    glVertex2f(-0.508608553044, 0.3595115682281);//G22
    glVertex2f(-0.4976812078282, 0.3535727936543); //F22
    glVertex2f(-0.4540933856379, 0.3602728675073); //W23
    glVertex2f(-0.4354795579644, 0.3620179138517); //V23
    glVertex2f(-0.4488582466047, 0.3643446423108);//U23
    glVertex2f(-0.4343161937348, 0.3675438939422); //T23
    glVertex2f(-0.4601691638938, 0.3730884872031); //S23
    glEnd();

    //Hat sharp Phase

    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);

    glVertex2f(-0.5324120085967, 0.4132103872745); //U22
    glVertex2f(-0.5557806026573, 0.4055798259486); //T22
    glVertex2f(-0.5691340849776, 0.4031952755342);//S22
    glVertex2f(-0.5665110795219 ,0.4005722700784); //R22
    glVertex2f(-0.5355119241354, 0.4031952755342); //Q22

    glEnd();

    //Hand

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2f(-0.6460918890339, 0.2978225035081); //C22
    glVertex2f(-0.6110612242307, 0.2915125800089); //U27
    glVertex2f(-0.599820883082, 0.2935131465918);//V27
    glVertex2f(-0.5937079006987, 0.2875827089398); //W27
    glVertex2f(-0.5724377946139, 0.2837079221724); //B22
    glVertex2f(-0.494633281804, 0.3092503837857); //A22
    glVertex2f(-0.4976812078282, 0.3535727936543);//F22
    glVertex2f(-0.553033249933, 0.3190037068883);//E22
    glVertex2f(-0.5984636743787, 0.3037756630716); //D22

    glEnd();


    //upper body

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2f(-0.4976812078282, 0.3535727936543);//F22
    glVertex2f(-0.494633281804, 0.3092503837857); //A22
    glVertex2f(-0.4513333862673, 0.2777595506682);//Z21
    glVertex2f(-0.3869091013787, 0.2826183051817); //G24
    glVertex2f(-0.3496814460316, 0.2677854112543); //F24
    glVertex2f(-0.3162347244307, 0.2733113913449); //E24
    glVertex2f(-0.3141988370289, 0.309084841405);//D24
    glVertex2f(-0.3240874329805, 0.3093756824624);//C24
    glVertex2f(-0.3575341545814, 0.310539046692); //B24
    glVertex2f(-0.3810922802307, 0.3244994174472); //A24
    glVertex2f(-0.441005538055, 0.3532926821297); //Z23
    glVertex2f(-0.4540933856379, 0.3602728675073); //W23
    glEnd();


    //Lower body

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2f(-0.4513333862673, 0.2777595506682);//Z21
    glVertex2f(-0.5455369079553, 0.240253621215); //J24
    glVertex2f(-0.5499682908322, 0.2285421093261);//K24
    glVertex2f(-0.4952090595676, 0.1839117532087); //L24
    glVertex2f(-0.4898280946456, 0.1750489874548); //M24
    glVertex2f(-0.4759513199637, 0.1746003427975); //Z24
    glVertex2f(-0.4614130867907, 0.171575045721);//B25
    glVertex2f(-0.4453488505378, 0.1695886232068); //T25
    glVertex2f(-0.4355608248445, 0.1691535998426); //U25
    glVertex2f(-0.4277304042899, 0.170349914094); //V25
    glVertex2f(-0.4287092068592, 0.1738301010072);//W25
    glVertex2f(-0.4145709475244, 0.170349914094); //Z25
    glVertex2f(-0.38066742649, 0.1732509037213); //A26
    glVertex2f(-0.3327028268984, 0.1993955420233); //B26
    glVertex2f(-0.3565533852501 , 0.2024354865511);//C26
    glVertex2f(-0.3725063115439, 0.2100170752848); //D26
    glVertex2f(-0.3723483617786, 0.2191781616713); //E26
    glVertex2f(-0.4012531688257, 0.2324459419552); //F26
    glVertex2f(-0.4039383148355, 0.2392377818624); //G26
    glVertex2f(-0.3927238815003, 0.2521896626158);//H26
    glVertex2f(-0.3882228158251, 0.2608278988578); //I24
    glVertex2f(-0.3844244876449, 0.2703237193083); //H24
    glVertex2f(-0.3869091013787, 0.2826183051817); //G24
    glEnd();

    //Front Leg
    glPushMatrix();
    glTranslatef(0.0f, 0.01f, 0.0f);

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2f(-0.4812655120916, 0.1745573497223);//G12
    glVertex2f(-0.4815753934812, 0.1600962182062); //U12
    glVertex2f(-0.4850873825637, 0.1514195392966);//V12
    glVertex2f(-0.4869466709015, 0.1450153239109); //W12
    glVertex2f(-0.4884960778497, 0.1394374588975); //Z12
    glVertex2f(-0.4912850103563, 0.1355122946289); //A13
    glVertex2f(-0.5036802659416, 0.1343760628669);//J12
    glVertex2f(-0.4997551016729, 0.1316904241567); //C13
    glVertex2f(-0.4866367895119, 0.1301410172086); //D13
    glVertex2f(-0.4818852748709, 0.1312772489706); //E13
    glVertex2f(-0.4672175557617, 0.1444988549281);//F13
    glVertex2f(-0.4697999006753, 0.1484240191968); //G13
    glVertex2f(-0.4677340247444, 0.1485273129933); //H13
    glVertex2f(-0.4641187418654, 0.1461515556728); //l13
    glVertex2f(-0.4579211140728, 0.149973426145);//j13
    glVertex2f(-0.4698755125084, 0.1703358813453); //L12
    glVertex2f(-0.4675590640932, 0.164888060828); //H12

    glEnd();
    glPopMatrix();


    //Back Leg
    glPushMatrix();
    glTranslatef(0.01f, 0.01f, 0.0f);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2f(-0.4543189400492, 0.1701417715099);//l12
    glVertex2f(-0.4563717071246, 0.1582369298684); //j12
    glVertex2f(-0.4558552381419, 0.1504898951277);//k12
    glVertex2f(-0.456061825735, 0.1446021487247); //l12
    glVertex2f(-0.458540876852, 0.1352024132392); //M12
    glVertex2f(-0.4613298093587, 0.1279718474812); //N12
    glVertex2f(-0.466701086779, 0.1230137452471);   //O12
    glVertex2f(-0.475067884299, 0.1209478693162); //P12
    glVertex2f(-0.4712460138269, 0.1183655244026); //Q12
    glVertex2f(-0.4543058311937, 0.1179523492165); //R12
    glVertex2f(-0.4672175557617, 0.1444988549281);//F13
    glVertex2f(-0.4416006942189, 0.1303476048017); //S12
    glVertex2f(-0.442943513574, 0.1341694752738); //T12
    glVertex2f(-0.4372623547641, 0.1324134807326); //Q13
    glVertex2f(-0.4308581393784, 0.1384045209321);//P13
    glVertex2f(-0.4438731577428, 0.1519360082793); //O13
    glVertex2f(-0.4450513861298, 0.1646182269369); //N13
    glEnd();

    glPopMatrix();


    //Broom Brush
    glPushMatrix();
    glTranslatef(-0.01f, 0.023f, 0.0f);
    glBegin(GL_POLYGON);
    glColor3ub(150, 105, 25);

    glVertex2f(-0.3727039192255, 0.2223922836999);//H12
    glVertex2f(-0.376718712988, 0.2175986659684); //j12
    glVertex2f(-0.3730002622554, 0.2175986659684);//k12
    glVertex2f(-0.376718712988, 0.2148502458616); //l12
    glVertex2f(-0.3694434832937, 0.2116168104419); //M12
    glVertex2f(-0.3742936364233, 0.2091917338771); //N12
    glVertex2f(-0.35, 0.21);   //O12
    glVertex2f(-0.3388875185773, 0.2046649242895); //P12
    glVertex2f(-0.3173851730362, 0.1854259835422); //Q12
    glVertex2f(-0.2894159566556, 0.1728155854053); //R12
    glVertex2f(-0.2908710025945, 0.175887349054);//F13
    glVertex2f(-0.2635484732979, 0.1556783776808); //S13
    glVertex2f(-0.2847274752971, 0.1783124256188); //R13
    glVertex2f(-0.2803623374804, 0.1783124256188); //Q13
    glVertex2f(-0.250453059848, 0.1640853097721);//P13
    glVertex2f(-0.2680752828855, 0.1808991739546); //O13
    glVertex2f(-0.251261418703, 0.1718455547794); //N13
    glVertex2f(-0.2536864952678, 0.1754023337411); //P12
    glVertex2f(-0.2383276770241, 0.1681271040467); //Q12
    glVertex2f(-0.2685602981985, 0.1909228237557); //R12
    glVertex2f(-0.2583749766264, 0.187366044794);//F13
    glVertex2f(-0.2669435804886, 0.1946412744884); //S13
    glVertex2f(-0.2417227842148, 0.188012731878); //R13
    glVertex2f(-0.2517464340159, 0.1952879615723); //Q13
    glVertex2f(-0.2300824167038, 0.1914078390687);//P13
    glVertex2f(-0.25, 0.2); //O13
    glVertex2f(-0.2412377689018, 0.2015931606408); //N13
    glVertex2f(-0.2554648847486, 0.2048265960605); //P12
    glVertex2f(-0.2564349153745, 0.2078983597092); //Q12
    glVertex2f(-0.2441478607796, 0.210323436274); //R12
    glVertex2f(-0.2548181976647, 0.2164669635715);//F13
    glVertex2f(-0.2452795631765, 0.221963803785); //S13
    glVertex2f(-0.26225509913, 0.2213171167011); //R13
    glVertex2f(-0.2498063727641, 0.2255205827467); //Q13
    glVertex2f(-0.2706620312213, 0.2260055980597);//P13
    glVertex2f(-0.2941044380142, 0.2310174229602); //O13
    glVertex2f(-0.3146367529295, 0.2303707358763); //N13
    glVertex2f(-0.3461627482717, 0.222125475556);//P13
    glVertex2f(-0.3523062755692, 0.222125475556); //O13
    glVertex2f(-0.3645933301641, 0.2308557511892); //N13

    glEnd();
    glPopMatrix();

    //dandi
    glPushMatrix();
    glTranslatef(-0.01f, 0.023f, 0.0f);
    glBegin(GL_LINES);
    glLineWidth(2);
    glColor3ub(153,101,21);
    glVertex2f(-0.6515749481072, 0.2945418174205);
    glVertex2f(-0.3727039192255, 0.2223922836999);
    glEnd();
    glPopMatrix();


}


void GhostUpdate(int value)//A10
{

    ghostmovement-=speed;// speedMultiplier;
    ghostmovement3rd -= speed;// speedMultiplier;
    if(ghostmovement<(-1.4))
    {
        ghostmovement = 1.8;
        ghostmovement3rd = 1.8f;
    }
    glutPostRedisplay();
    glutTimerFunc(resumeGhostMovement,GhostUpdate,0);

}



void waterfall()//F47
{

    glPushMatrix();
    glScalef(0.5,1.2,1.0);
    glTranslatef(0.1f, -0.1f, 0.0f);
    glBegin(GL_QUADS);
    glColor3ub(153,204,255); //
    glVertex2f(0.1349744290931, 0.3208738313581);
    glVertex2f(0.1418331837972, 0.3208524860652);
    glVertex2f(0.1423394920046, 0.3873965155746);
    glVertex2f(0.135124841831, 0.3873721417564);
    glEnd();
    glPopMatrix();
    glLoadIdentity();

}


void Fountain()//F48
{

    //border
    //water color
    glBegin(GL_POLYGON);
    glColor3ub(28,163,236);


    glVertex2f(0.0523562861658, 0.2476434939835); //a14
    glVertex2f(0.0324222507317, 0.2384881849969); //j14
    glVertex2f(0.1486274339599, 0.1732298427639); //p14
    glVertex2f(0.269855896002, 0.2418813198872); //Q14
    glVertex2f(0.2510867691315, 0.2492509080094);    //J15
    glVertex2f(0.2032832352019, 0.223610321721);  //V15
    glVertex2f(0.093889520929, 0.2240125155838);    //P15

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);


    glVertex2f(0.0809510306663, 0.3264676497324); //a14
    glVertex2f(0.0630529593538, 0.3158875462336); //j14
    glVertex2f(0.11, 0.3); //p14
    glVertex2f(0.1121864243235, 0.2612067545737); //Q14
    glVertex2f(0.1858866217781, 0.2605727743806);    //J15
    glVertex2f(0.19, 0.3);  //V15
    glVertex2f(0.24, 0.32);    //P15
    glVertex2f(0.2203096556183,0.3266695675172);    //P15

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(28,163,236);


    glVertex2f(0.1484576960699, 0.3984241447819); //a14
    glVertex2f(0.0679257725531, 0.3831508489425); //j14
    glVertex2f(0.1197624129777, 0.3771340960361); //p14
    glVertex2f(0.120688067271, 0.3563068744369); //Q14
    glVertex2f(0.1794671148953, 0.3567697015836);    //J15
    glVertex2f(0.179929942042, 0.3762084417428);  //V15
    glVertex2f(0.2303781010267, 0.3873162932624);    //P15


    glEnd();



    //ground
    //bottom left
    glBegin(GL_POLYGON);
    glColor3ub(96,96,96);

    glVertex2f(0.0226193961984, 0.1645379198803);    //T14
    glVertex2f(0.1106868245775, 0.1033203172265);  //I15
    glVertex2f(0.1497808412925, 0.1029382910046);    //G15
    glVertex2f(0.15, 0.16); //v14
    glVertex2f(0.0125238617257, 0.2390730360938); //v14

    glEnd();

    //bottom left border

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2f(0.0125238617257, 0.2390730360938);    //T14
    glVertex2f(0.15, 0.16);  //I15
    glVertex2f(0.1486274339599, 0.1732298427639);    //G15
    glVertex2f(0.0324222507317, 0.2384881849969); //v14
    glVertex2f(0.0523562861658, 0.2476434939835); //v14
    glVertex2f(0.0460897089614, 0.251208960324); //v14

    glEnd();

    //bottom right
    glBegin(GL_POLYGON);
    glColor3ub(96,96,96);

    glVertex2f(0.1497808412925, 0.1029382910046);    //G15
    glVertex2f(0.1766299965589, 0.1026759214091);  //I15
    glVertex2f(0.1981098571392, 0.1076162893426);    //G15
    glVertex2f(0.2816665147965, 0.1675451003615); //v14
    glVertex2f(0.2855328897009, 0.2429394109983); //v14
    glVertex2f(0.15, 0.16); //v14

    glEnd();

    //bottom right border
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2f(0.2855328897009, 0.2429394109983);    //P15
    glVertex2f(0.15, 0.16);  //V15
    glVertex2f(0.1486274339599, 0.1732298427639);//S15
    glVertex2f(0.269855896002, 0.2418813198872);    //T15
    glVertex2f(0.2510867691315, 0.2492509080094); //U15
    glVertex2f(0.25705089846, 0.2524895269178); //T14

    glEnd();

    //2nd floor
    //left side
    glBegin(GL_QUADS);
    glColor3ub(128,128,128);

    glVertex2f(0.0460897089614, 0.251208960324);    //Q14
    glVertex2f(0.093889520929, 0.2240125155838);  //R14
    glVertex2f(0.0914235729976, 0.29861158597);//V14
    glVertex2f(0.0420050067357, 0.3155649096876);    //P14
    glEnd();

    //left side middle left wall
    glBegin(GL_QUADS);
    glColor3ub(136,140,141);
    glVertex2f(0.093889520929, 0.2240125155838);  //R14
    glVertex2f(0.1121864243235, 0.2612067545737);//B15
    glVertex2f(0.11, 0.3);    //A15
    glVertex2f(0.0914235729976, 0.29861158597);//V14
    glEnd();

    //left side border

    glBegin(GL_POLYGON);
    glColor3ub(136,140,141);
    glVertex2f(0.0420050067357, 0.3155649096876);  //P14
    glVertex2f(0.1121864243235, 0.2612067545737);//V14
    glVertex2f(0.11, 0.3);    //A15
    glVertex2f(0.0630529593538, 0.3158875462336);//Z14
    glVertex2f(0.0809510306663, 0.3264676497324);//W14
    glVertex2f(0.072269562536, 0.3298460454098);//J14
    glEnd();

    //middle floor

    glBegin(GL_QUADS);
    glColor3ub(102,178,255);
    glVertex2f(0.093889520929, 0.2240125155838);  //R14
    glVertex2f(0.2035102784564, 0.223416102322);//S14
    glVertex2f(0.1858866217781, 0.2605727743806);    //C15
    glVertex2f(0.1121864243235, 0.2612067545737);//B15
    glEnd();

    //right side

    glBegin(GL_QUADS);
    glColor3ub(128,128,128);
    glVertex2f(0.2035102784564, 0.223416102322);//S14
    glVertex2f(0.25705089846, 0.2524895269178); //T14
    glVertex2f(0.2595868192327, 0.3181064769096);//U14
    glVertex2f(0.2083107816742, 0.2982421429704);    //H15
    glEnd();

    //right side middle left wall
    glBegin(GL_QUADS);
    glColor3ub(136,140,141);
    glVertex2f(0.2035102784564, 0.223416102322);//S14
    glVertex2f(0.1858866217781, 0.2605727743806);    //C15
    glVertex2f(0.19, 0.3);    //D15
    glVertex2f(0.2083107816742, 0.2982421429704);//H15
    glEnd();

    //right side border
    glBegin(GL_POLYGON);
    glColor3ub(136,140,141);
    glVertex2f(0.2595868192327, 0.3181064769096);//U14
    glVertex2f(0.2083107816742, 0.2982421429704);    //H15
    glVertex2f(0.19, 0.3);    //D15
    glVertex2f(0.24, 0.32);//F15
    glVertex2f(0.2203096556183, 0.3266695675172);//G15
    glVertex2f(0.2274502255224, 0.328924484329);//G14
    glEnd();


    //3rd floor starts here
    //left side
    glBegin(GL_QUADS);
    glColor3ub(128,128,128);

    glVertex2f(0.072269562536, 0.3298460454098);    //J14
    glVertex2f(0.1057197643293, 0.3165840498598);  //l14
    glVertex2f(0.1031006356983, 0.3780597503294);//C14
    glVertex2f(0.0679257725531, 0.3831508489425);    //A14
    glEnd();

    //left side middle left wall
    glBegin(GL_QUADS);
    glColor3ub(136,140,141);
    glVertex2f(0.1057197643293, 0.3165840498598);  //l14
    glVertex2f(0.120688067271, 0.3563068744369);//L14
    glVertex2f(0.1197624129777, 0.3771340960361);    //K14
    glVertex2f(0.1031006356983, 0.3780597503294);//C14
    glEnd();

    //middle floor

    glBegin(GL_QUADS);
    glColor3ub(102,178,255);
    glVertex2f(0.1057197643293, 0.3165840498598);  //l14
    glVertex2f(0.1912886414304, 0.317505036721);//O14
    glVertex2f(0.1794671148953, 0.3567697015836);    //M14
    glVertex2f(0.120688067271, 0.3563068744369);//L14
    glEnd();

    //Right side
    glBegin(GL_QUADS);
    glColor3ub(128,128,128);

    glVertex2f(0.1912886414304, 0.317505036721);//O14
    glVertex2f(0.2274502255224, 0.328924484329);//G14
    glVertex2f(0.2303781010267, 0.3873162932624);//E14
    glVertex2f(0.197054546468, 0.3794482317693);    //A14
    glEnd();

    //right side middle right wall
    glBegin(GL_QUADS);
    glColor3ub(136,140,141);
    glVertex2f(0.1912886414304, 0.317505036721);//O14
    glVertex2f(0.2303781010267, 0.3873162932624);//E14
    glVertex2f(0.179929942042, 0.3762084417428);    //N14
    glVertex2f(0.1794671148953, 0.3567697015836);    //M14
    glEnd();


    //top

    glBegin(GL_POLYGON);
    glColor3ub(128,128,128);
    glVertex2f(0.1197624129777, 0.3771340960361);    //K14
    glVertex2f(0.1031006356983, 0.3780597503294);//C14
    glVertex2f(0.0679257725531, 0.3831508489425);    //A14
    glVertex2f(0.1484576960699, 0.3984241447819);    //D14
    glVertex2f(0.2303781010267, 0.3873162932624);//E14
    glVertex2f(0.197054546468, 0.3794482317693);//F14
    glVertex2f(0.179929942042, 0.3762084417428);    //N14
    glEnd();


    //bottom traingle


    glBegin(GL_TRIANGLES);
    glColor3ub(96,96,96);
    glVertex2f(0.1981098571392, 0.1076162893426);    //N15
    glVertex2f(0.1106868245775, 0.1033203172265);//L15
    glVertex2f(0.1484750949575, 0.0801595731801);    //E15
    glEnd();

    glPushMatrix();
    glTranslatef(0.0,watermove,0.0);
    waterfall();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.02f,watermove2,0.0f);
    waterfall();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.035f,watermove3,0.0f);
    waterfall();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.05f,watermove4,0.0f);
    waterfall();
    glPopMatrix();

}


void fountainwater(int value) {
    if (fountainRunning) {
        watermove -= 0.002;
        watermove2 -= 0.002;
        watermove3 -= 0.002;
        watermove4 -= 0.002;

        if (watermove < -0.03) {
            watermove = 0.05;
        }

        if (watermove2 < -0.03) {
            watermove2 = 0.053;
        }

        if (watermove3 < -0.03) {
            watermove3 = 0.048;
        }

        if (watermove4 < -0.03) {
            watermove4 = 0.045;
        }

        glutPostRedisplay();
        glutTimerFunc(15, fountainwater, 0);
    }
}

void mouseClick(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        fountainRunning = true;  // Start the fountain on left mouse click
        fountainwater(0);        // Start the timer function
    } else if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) {
        fountainRunning = false; // Stop the fountain on right mouse click
    }
}


void circle_lamp(float radius, float cX, float cY, float alpha) //F6
{
    if (isColorOn)
    {
        glBegin(GL_POLYGON);
        for (int i = 0; i < 200; i++)
        {
            float pi = 3.1416;
            float A = (i * 2 * pi) / 200;
            float r = radius;
            float x = r * cos(A);
            float y = r * sin(A);

            // Adjust the brightness based on glow effect
            float brightness = 0.5f + 0.5f * alpha;
            glColor3f(241.0f / 255.0f * brightness, 235.0f / 255.0f * brightness, 156.0f / 255.0f * brightness);
            glVertex2f(x + cX, y + cY);
        }
        glEnd();
    }
    else
    {
        glBegin(GL_POLYGON);
        for (int i = 0; i < 200; i++)
        {
            float pi = 3.1416;
            float A = (i * 2 * pi) / 200;
            float r = radius;
            float x = r * cos(A);
            float y = r * sin(A);

            // Grey color when turned off
            glColor3ub(224.0f, 224.0f, 224.0f);
            glVertex2f(x + cX, y + cY);
        }
        glEnd();
    }
}


void Lampost() //F20
{
    circle_lamp(0.0145239316937, 0.1477264524784, -0.0772219536772, glowAlpha); // left
    circle_lamp(0.0197921878293, 0.192787594241, -0.0553003171441, glowAlpha); // middle
    circle_lamp(0.0145239316937, 0.2379955904464, -0.0770311098337, glowAlpha); // right

    // Lamp stand
    glBegin(GL_QUADS);
    glColor3ub(0, 0, 0); // Red
    glVertex2f(0.1890898766711, -0.1517335194932);    //T12
    glVertex2f(0.1959794679766, -0.1516306897722);    //U12
    glVertex2f(0.1956233509927, -0.0748883028168);    //Z12
    glVertex2f(0.1888341164192, -0.074693633317);    //V12
    glEnd();

    glLineWidth(6.0);
    glBegin(GL_LINES);
    glColor3ub(0.0f, 0.0f, 0.0f);
    glVertex2f(0.1475994640695, -0.0917453302057);
    glVertex2f(0.1475576020546, -0.1039184550827);
    glEnd();

    glLineWidth(6.0);
    glBegin(GL_LINES);
    glColor3ub(0.0f, 0.0f, 0.0f);
    glVertex2f(0.1475576020546, -0.1039184550827);
    glVertex2f(0.2380067980133, -0.1041399677207);
    glEnd();

    glLineWidth(6.0);
    glBegin(GL_LINES);
    glColor3ub(0.0f, 0.0f, 0.0f);
    glVertex2f(0.2380067980133, -0.1041399677207);
    glVertex2f(0.2381165549024, -0.0915545377846);
    glEnd();
}

void set_lampPost() //F21
{
    glPushMatrix();
    glTranslatef(-1.13f, 0.15f, 0.0f);
    Lampost();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-0.15f, 0.15f, 0.0f);
    Lampost();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.73f, 0.15f, 0.0f);
    Lampost();
    glPopMatrix();
}

void updateGlow(int value) //A6
{
    // Increase glowAlpha gradually
    glowAlpha += 0.01f;
    if (glowAlpha > 1.0f)
        glowAlpha = 0.0f;

    // Redraw
    glutPostRedisplay();

    // Call updateGlow again after 50 milliseconds
    glutTimerFunc(50, updateGlow, 0);
}


void Froghopper() //F33
{
    //Stand
    glPushMatrix();
    glScalef(1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 0.0f, 0.0f); // Red
    glVertex2f(0.2975812230974f,-0.2706178068053f-0.5);    // x, y
    glColor3ub(178,34,34);
    glVertex2f(0.3626871800881f,-0.2697379965757f-0.5);    // x, y // lowerpoint
    glVertex2f(0.3500357081808, 0.1359212367917);    // x, y
    glColor3ub(255.0f, 0.0f, 0.0f);
    glVertex2f(0.3099537246946, 0.1361314569848);    // x, y upper point
    glEnd();
    glPopMatrix();



    glPushMatrix();
    glTranslatef(0.0,benchPosition,0.0);

    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 255.0f, 0.0f); // Red
    glVertex2f(0.2395137479435f, -0.1861560247634f);    // x, y
    glVertex2f(0.4185551296679f, -0.1830766889597f);    // x, y
    glVertex2f(0.4172354143235f, -0.1544828564976f);    // x, y
    glVertex2f(0.2395421009271f, -0.1591253399728f);    // x, y
    glEnd();

    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 250.0f, 0.0f); // Red
    glVertex2f(0.2295641457125f, -0.2284237649445f);    // x, y
    glVertex2f(0.4216344654715f, -0.2121104265367f);    // x, y
    glVertex2f(0.4185551296679f, -0.1830766889597f);    // x, y
    glVertex2f(0.2395137479435f, -0.1861560247634f);    // x, y
    glEnd();

    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 120.0f, 0.0f); // Red
    glVertex2f(0.2295641457125f, -0.2284237649445f);    // x, y
    glVertex2f(0.4277931370787f, -0.2248676748659f);    // x, y
    glVertex2f(0.4216344654715f, -0.2121104265367f);    // x, y
    glVertex2f(0.2375858385045f, -0.2165110616948f);    // x, y
    glEnd();

    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 230.0f, 0.0f); // Red
    glVertex2f(0.2295641457125f, -0.2495633923737f);
    glVertex2f(0.4281485245931f, -0.244438634209f);
    glVertex2f(0.4277931370787f, -0.2248676748659f);
    glVertex2f(0.2295641457125f, -0.2284237649445f);
    glEnd();

    glPopMatrix();



}

void updateFroghopper(int value) //A5
{

    if(f==false){
        benchPosition += stopstart;
        if(benchPosition > 0.1)
        {
            //benchPosition=(-0.5);
            f=true;
        }
    }
    else if(f==true){
        benchPosition -= stopstart;
        if(benchPosition < (-0.45))
        {
            //benchPosition=(0.5);
            f=false;
        }
    }

    glutPostRedisplay();
    glutTimerFunc(benchSpeed, updateFroghopper, 0);

}

void horse() //F27
{


    //Horse Head
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(161,61,45); // Red
    glVertex2f(0.6230289295598, -0.07153140419);    // x, y
    glVertex2f(0.6204933293862, -0.0845218808048);    // x, y
    glVertex2f(0.5952168105742, -0.1214119352872);    // x, y
    glVertex2f(0.6152677031054, -0.1300933856185);    // x, y
    glVertex2f(0.6353763352827, -0.1138653666684);    // x, y
    glVertex2f(0.6630081138722, -0.0945747376603);   // x, y
    glVertex2f(0.6477565923213, -0.0799660124065);    // x, y
    glVertex2f(0.63, -0.08);
    glEnd();

    // Horse Ear
    glBegin(GL_TRIANGLES);
    glColor3ub(0.0f, 0.0f, 0.0f);
    glVertex2f(0.6204933293862, -0.0745218808048f);    // x, y
    glVertex2f(0.63, -0.07f);    // x, y
    glVertex2f(0.6230289295598, -0.06153140419f);    // x, y
    glEnd();

    //Horse Body
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(161,61,45); // Red
    glVertex2f(0.6353763352827, -0.1138653666684);    // s6
    glVertex2f(0.6427847787164, -0.1322100837424);    // t6
    glVertex2f(0.6364346843446, -0.1614910744567);    // u6
    glVertex2f(0.6371402503859, -0.1741912632002);    // v6
    glVertex2f(0.6652170320805, -0.1823792364382);    // a7
    glVertex2f(0.7469470057857, -0.1818270068861);   // b7
    glVertex2f(0.7734540242846, -0.1790658591258);    // e7
    glVertex2f(0.7733144963582, -0.142793574362);       // o6
    glVertex2f(0.7695884174202, -0.1348874949609);      // h7
    glVertex2f(0.7581448264701, -0.126565555412);    // n6
    glVertex2f(0.7330972320037, -0.1258599893707);    // m6
    glVertex2f(0.7147525149297, -0.1293878195772);    // l6
    glVertex2f(0.7034634582688, -0.1290350365565);    // k6
    glVertex2f(0.6886465714014, -0.12550720635);   //j6
    glVertex2f(0.6630081138722, -0.0945747376603); //i6
    glEnd();

    //Horse Front Leg
    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
    glColor3ub(44,45,45); // Red

    glVertex2f(0.6342368822203, -0.2248317806397);    // w6
    glVertex2f(0.6485590055079, -0.2244737275575);    // Z6
    glVertex2f(0.6652170320805, -0.1823792364382);    // A7
    glVertex2f(0.6371402503859, -0.1741912632002);    // v6
    glEnd();

    //Horse Front Leg Horseshoe
    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
    glColor3ub(0.0f, 0.0f, 0.0f); // Red

    glVertex2f(0.6306563513984, -0.2309186830369);    // L7
    glVertex2f(0.6478766558479, -0.2307468511194);    // J7
    glVertex2f(0.6485590055079, -0.2244737275575);    // Z6
    glVertex2f(0.6342368822203, -0.2248317806397);    // w6
    glEnd();


    //Horse Back Leg
    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
    glColor3ub(44,45,45); // Red

    glVertex2f(0.7717292657813, -0.2245769480091);    // C7
    glVertex2f(0.7835450174936, -0.2241156744753);    // D7
    glVertex2f(0.7734540242846, -0.1790658591258);    // E7
    glVertex2f(0.7469470057857, -0.1818270068861);    // B7
    glEnd();

    //Horse Back Leg Horseshoe
    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
    glColor3ub(0.0f, 0.0f, 0.0f); // Red

    glVertex2f(0.7692518015035, -0.2298319430705);    // K7
    glVertex2f(0.7855341793726, -0.2297248716381);    // L7
    glVertex2f(0.7835450174936, -0.2241156744753);    // D7
    glVertex2f(0.7717292657813, -0.2245769480091);    // C7
    glEnd();


    //Horse Lengur

    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(0.0f, 0.0f, 0.0f); // Red

    glVertex2f(0.7733144963582, -0.142793574362);    // O6
    glVertex2f(0.8, -0.15);                             // P6
    glVertex2f(0.803274420096, -0.1702301862928);    // R6
    glVertex2f(0.8353037341156, -0.1531110701789);    // F7
    glVertex2f(0.8043788792001, -0.1282607403361);    // G7
    glVertex2f(0.7695884174202, -0.1348874949609);    // H7
    glEnd();

}

void Carousel() //F28
{
    //Horse Building Structure
    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
    glColor3ub(184, 173, 173); // Red

    glVertex2f(0.6469362786402, -0.2307682123178);    // H8
    glVertex2f(0.7742691404413, -0.2298197125607);    // K8
    glVertex2f(0.7708206462465, -0.0131777323474);    // l8
    glVertex2f(0.6440323872888, -0.0149066631513);    // G8
    glEnd();
    //Triangle
    glBegin(GL_TRIANGLES);              // Each set of 4 vertices form a quad
    glColor3ub(185,96,236); // Red
    glVertex2f(0.5072739941155, 0.0355885447244);    // N7
    glVertex2f(0.9111285277335, 0.0365501031378);    //v7                      // T7
    glVertex2f(0.7063165856844, 0.15962958005);    // V7
    glEnd();


    //Triangle Base

    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
    glColor3ub(56,172,236); // Red
    glVertex2f(0.4512152034121, 0.007414334689);    // W7
    glVertex2f(0.962155655219, 0.0098746783722);    //E8                     // T7
    glVertex2f(0.9611295652291, 0.0375116615512);    // U7
    glVertex2f(0.452465164553, 0.0365501031378);    // M7
    glEnd();

    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
    glColor3ub(188,207,236); // Red
    glVertex2f(0.4538499988523, -0.0154829734193);    // F8
    glVertex2f(0.9540873114671, -0.0126014220794);    //J8                    // T7
    glVertex2f(0.962155655219, 0.0098746783722);    //E8
    glVertex2f(0.4512152034121, 0.007414334689);    // W7
    glEnd();

    //Leg Basement

    //First Basement
    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
    glColor3ub(52.0f, 61.0f, 235.0f); // Red
    glVertex2f(0.4569623148533, -0.2858343211071);    //p8
    glVertex2f(0.9647104079067, -0.2798019186316);    //n8                    // T7
    glVertex2f(0.9629772196723, -0.2285125058642);    // m8
    glVertex2f(0.4538499988523, -0.2321756341833);    // l8
    glEnd();


    //Bottom Basement

    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
    glColor3ub(56,172,236); // Red
    glVertex2f(0.4359129315107, -0.3051218849393);    //R8
    glVertex2f(0.9848799046873, -0.3014903503868);    //S8                    // T7
    glVertex2f(0.9862766869929, -0.2792028553237);    //O8
    glVertex2f(0.4340971642345, -0.2857537006596);    //Q8
    glEnd();


    /*glPushMatrix();
    glTranslatef(-0.15, 0.0f, 0.0f);
    horse();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.15, 0.005f, 0.0f);
    horse();
    glPopMatrix();

    */

    }

    void TentHouse()//F36
{

    //Whole Border
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 0.0f, 0.0f); // Red
    glVertex2f(-0.391172070257, -0.1028416617228);    // x, y
    glVertex2f(-0.5352946604884, -0.2137213219901);    // x, y
    glVertex2f(-0.5341626405179, -0.4044666870249);    // x, y
    glVertex2f(-0.2426674981056, -0.4039006770396);    // x, y
    glVertex2f(-0.245497548032, -0.2165513719164);
    glEnd();


    //Left White part top
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 255.0f, 255.0f); // White
    glVertex2f(-0.391172070257, -0.1028416617228);    // x, y
    glVertex2f(-0.4887871675063, -0.2320600455263);    // x, y
    glVertex2f(-0.440631330625, -0.2320024348871);
    glEnd();


    //Left White part top
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 255.0f, 255.0f); // White
    glVertex2f(-0.391172070257, -0.1028416617228);    // x, y
    glVertex2f(-0.4887871675063, -0.2320600455263);    // x, y
    glVertex2f(-0.440631330625, -0.2320024348871);
    glEnd();

    //Left White part down
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 255.0f, 255.0f); // White
    glVertex2f(-0.4887871675063, -0.2320600455263);    // x, y
    glVertex2f(-0.4866178017555, -0.3993725971575);
    glVertex2f(-0.4396389729784, -0.3999386071427);
    glVertex2f(-0.440631330625, -0.2320024348871);
    glEnd();


    //Right White part top
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 255.0f, 255.0f); // White
    glVertex2f(-0.391172070257, -0.1028416617228);    // x, y
    glVertex2f(-0.337876042845, -0.2321057353565);    // x, y
    glVertex2f(-0.2924763768091, -0.2301356115628);
    glEnd();

    //Right White part down
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 255.0f, 255.0f); // White
    glVertex2f(-0.2924763768091, -0.2301356115628);    // x, y
    glVertex2f(-0.2924763768091, -0.3991556327941);
    glVertex2f(-0.34, -0.4003490456219);
    glVertex2f(-0.337876042845, -0.2321057353565);
    glEnd();

    //Middle Black Door
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(0.0f, 0.0f, 0.0f); // White
    glVertex2f(-0.4396389729784, -0.3999386071427);    // x, y
    glVertex2f(-0.34, -0.4003490456219);
    glVertex2f(-0.366623684879, -0.3246592791023);
    glVertex2f(-0.3711517647611, -0.2827745401926);

    glVertex2f(-0.3768683954017, -0.2325145418793);
    glVertex2f(-0.4023856124878, -0.2325145418793);
    glVertex2f(-0.386623684879, -0.3246592791023);

    glEnd();

    //Middle Door Left Brown
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 215.0f, 0.0f); // White
    glVertex2f(-0.4079424138035, -0.2839065601631);    // x, y
    glVertex2f(-0.4583173024922, -0.3110750394559);
    glVertex2f(-0.4396389729784, -0.3999386071427);
    glEnd();

    //Middle Door Right Brown
    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(255.0f, 215.0f, 0.0f); // White
    glVertex2f(-0.3711517647611, -0.2827745401926);    // x, y
    glVertex2f(-0.321908896043, -0.3127730694117);
    glVertex2f(-0.34, -0.4003490456219);
    glEnd();


    //Top Flag

    glBegin(GL_POLYGON);              // Each set of 4 vertices form a quad
    glColor3ub(235.0f, 204.0f, 52.0f); // yellow
    glVertex2f(-0.391172070257, -0.0686145571218);    // x, y
    glVertex2f(-0.391172070257, -0.0920908404058);
    glVertex2f(-0.346852357889, -0.0923102449225);
    glVertex2f(-0.36, -0.08);
    glVertex2f(-0.3455359307889, -0.0686145571218);
    glEnd();

    glLineWidth(4.0);
    glBegin(GL_LINES);
    glColor3f(0.0f,0.0f,0.0f);
    glVertex2f(-0.3911489791823, -0.0646577053519);
    glVertex2f(-0.391172070257, -0.1028416617228);
    glEnd();


}


void Bench()  //F22
{

    glPushMatrix();
    glScalef(0.028f,0.05f,1.0f);

    glLineWidth(2.5);

    //middle
    glBegin(GL_QUADS);
    glColor3f(0.749f,0.376f,0.024f);
    glVertex2f(14.0f,-7.0f);
    glVertex2f(14.0f,-5.0f);
    glVertex2f(18.0f,-5.0f);
    glVertex2f(18.0f,-7.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.749f,0.376f,0.024f);
    glVertex2f(16.0f,-8.0f);
    glVertex2f(14.0f,-7.0f);
    glVertex2f(18.0f,-7.0f);
    glVertex2f(20.0f,-8.0f);
    glEnd();

    //leg
    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(14.0f, -7.0f);    // x, y
    glVertex2f(14.0f, -9.0f);    // x, y
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(16.0f, -8.0f);    // x, y
    glVertex2f(16.0f, -9.0f);    // x, y
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(19.8f, -8.0f);    // x, y
    glVertex2f(19.8f, -9.0f);    // x, y
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(18.3f, -8.0f);    // x, y
    glVertex2f(18.3f, -9.0f);    // x, y
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(14.0f, -7.0f);    // x, y
    glVertex2f(16.0f, -8.0f);    // x, y
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(14.0f, -7.0f);    // x, y
    glVertex2f(18.0f, -7.0f);    // x, y
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(18.0f, -7.0f);    // x, y
    glVertex2f(20.0f, -8.0f);    // x, y
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(14.0f, -7.0f);    // x, y
    glVertex2f(14.0f, -5.0f);    // x, y
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(14.0f, -5.0f);    // x, y
    glVertex2f(18.0f, -5.0f);    // x, y
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(18.0f, -5.0f);    // x, y
    glVertex2f(18.0f, -7.0f);    // x, y
    glEnd();

    glPopMatrix();
    glLoadIdentity();



}

   void sky3()
{
    ///sky
    glBegin(GL_QUADS);            //// Each set of 4 vertices form a quad
    glColor3ub(64,64,64); //// sky-blue
    glVertex2f(-1.0f, -0.4f);    //// x, y
    glColor3ub(64,64,64);
    glVertex2f(1.0f, -0.4f);    //// x, y
    glVertex2f(1.0f, 1.0f);    //// x, y
    glColor3ub(32,32,32);
    glVertex2f(-1.0f, 1.0f);    //// x, y
    glEnd();
}

void displayDay()
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); //// Set background color to black and opaque
    glClear(GL_COLOR_BUFFER_BIT);         //// Clear the color buffer (background)

    sky3();
    ground();

        //1st bench
    glPushMatrix();
    glTranslatef(-1.35,0.25f,0.0f);
    Bench();
    glPopMatrix();

    //2nd bench
    glPushMatrix();
    glTranslatef(0.2,0.25f,0.0f);
    Bench();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.03f, -0.32f, 0.0f);
    Carousel();
    glPushMatrix();
    glTranslatef(-0.15, 0.0f, 0.0f);
    horse();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.15, 0.005f, 0.0f);
    horse();
    glPopMatrix();

    glPopMatrix();

    glPushMatrix();
    glTranslatef(-0.10f, -0.7f, 0.0f);
    Fountain();
    glPopMatrix();

    set_lampPost();


    glPushMatrix();
    glTranslatef(0.55f, 0.55f, 0.0f);
    Froghopper();
    glPopMatrix();

     //1st voot
    glPushMatrix();
    glTranslatef(-0.25f, 0.45f, 0.0f);
    glTranslatef(ghostmovement,0.0f,0.0f);
    Ghost();
    glPopMatrix();

   /* //2nd Voot
    glPushMatrix();
    glTranslatef(0.15f, 0.25f, 0.0f);
    glTranslatef(ghostmovement,0.0f,0.0f);
    Ghost();
    glPopMatrix();

    //3rd voot;
    glPushMatrix();
    glTranslatef(ghostmovement3rd,0.0f,0.0f);
    Ghost();
    glPopMatrix();
    */


    glPushMatrix();
    glScalef(1.5f,2.0f,1.0f);
    glTranslatef(0.65f, -0.15f, 0.0f);
    TentHouse();
    glPopMatrix();
    glLoadIdentity();

    glFlush();


   // glutSwapBuffers();  /// Render now
}

void handleKeypress(unsigned char key, int x, int y) //A16
{
	switch (key) {

	  ///////////////Frog Hopper/////////////////////////
        case 'h': //increase speed;
        benchSpeed -= 10;
        if(benchSpeed < 10){
            benchSpeed = 10;
        }

        break;
        case 'd'://decrease speed;
        benchSpeed += 10;
         if(benchSpeed > 1000){
            benchSpeed = 1000;
        }
        break;

        case 'f': // Stop;
            stopstart=0.0f;
            break;
        case 'g': // Start
            stopstart=0.02f;
            break;

        ////////////ghost/////////////
        case 'z':
            resumeGhostMovement -= 10; // increase ghost movement
            if(resumeGhostMovement<10)
            {
                resumeGhostMovement=10;
            }
            break;
        case 'x':
            resumeGhostMovement += 10; // dicrease ghost movement
            if(resumeGhostMovement>1000)
            {
                resumeGhostMovement=1000;
            }  // Resume ghost movement
            break;
        case 'c':
            speed = 0.0f;     // ghost stop

            break;
        case 'v':
            speed = 0.02f;   //start
            break;
            /////lamp//////
        case 'n':
            isColorOn = !isColorOn;
            break;
        glutPostRedisplay();
	}
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);                 //// Initialize GLUT
    glutInitWindowSize(2560, 1440);
    glutInitWindowPosition(0, 0);
    glutCreateWindow("Haunted Theme Park - Tanvir");
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glutDisplayFunc(displayDay);
    glutTimerFunc(benchSpeed, updateFroghopper, 0);
    glutKeyboardFunc(handleKeypress);
    glutTimerFunc(15, fountainwater, 0);
    glutTimerFunc(resumeGhostMovement,GhostUpdate,0);
    glutTimerFunc(50, updateGlow, 0);
    glutMouseFunc(mouseClick);
    glutMainLoop();           //// Enter the event-processing loop
    return 0;
}
