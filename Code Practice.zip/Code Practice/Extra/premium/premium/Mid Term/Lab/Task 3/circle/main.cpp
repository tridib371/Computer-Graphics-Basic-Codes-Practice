#include <iostream>
#include <GL/gl.h>
#include <GL/glut.h>
#include <windows.h>
#include <cmath>

using namespace std;

float _angle1 = 0.0f;

void drawScene() {
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity(); // Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);

    glPushMatrix();
    glTranslatef(0.3, 0.1, 0.0);
    glRotatef(_angle1, 0.0f, 0.0f, 1.0f);
    glTranslatef(-0.3, -0.1, 0.0);

    // Draw a larger circle with rainbow colors
    float radius = 0.1f;
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(0.3f, 0.1f); // Center of circle

    for (int i = 0; i <= 360; i++) {
        float angle = static_cast<float>(i) * 3.1415926f / 180.0f;
        float x = radius * cos(angle);
        float y = radius * sin(angle);

        // Set rainbow color based on angle
        glColor3f(cos(angle), sin(angle), 1.0 - cos(angle));

        glVertex2f(0.3f + x, 0.1f + y);
    }
    glEnd();

    glPopMatrix();
    glutSwapBuffers();
}

void update(int value) {
    _angle1 += 2.0f;
    glutPostRedisplay(); // Notify GLUT that the display has changed
    glutTimerFunc(20, update, 0); // Notify GLUT to call update again in 25 milliseconds
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(800, 800);
    glutCreateWindow("Transformation");
    glutDisplayFunc(drawScene);
    glutTimerFunc(20, update, 0); // Add a timer
    glutMainLoop();
    return 0;
}
