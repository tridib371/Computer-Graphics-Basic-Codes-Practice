#include <windows.h>
#include <GL/glut.h>
#include<iostream>
#include<cstdlib>

bool vVisible = false;

void frame()
{
    glColor3ub(135, 206, 250); // light blue color for the sky
    glBegin(GL_POLYGON);
    glVertex2f(-20,120);
    glVertex2d(200,120);
    glVertex2d(200,-80);
    glVertex2d(-20,-80);
    glVertex2d(200,120);
    glEnd();
}

void ground1()
{
    glColor3ub(34, 170, 34); // dark green color for the ground
    glBegin(GL_POLYGON);
    glVertex2f(-20,0);
    glVertex2f(200,0);
    glVertex2f(200,-20);
    glVertex2f(-20,-20);
    glEnd();

}

void ground2()
{
    glColor3ub(34, 170, 34); // dark green color for the ground
    glBegin(GL_POLYGON);
    glVertex2f(-20,-50);
    glVertex2f(200,-50);
    glVertex2f(200,-80);
    glVertex2f(-20,-80);
    glEnd();

}

void river()
{
    glColor3ub(60, 40, 255); // dark blue color for the river
    glBegin(GL_POLYGON);
    glVertex2f(-20,-20);
    glVertex2f(200,-20);
    glVertex2f(200,-50);
    glVertex2f(-20,-50);
    glEnd();

}


void mountain()
{
    glColor3ub(2,40,22);
    glBegin(GL_POLYGON);
    glVertex2f(0,0);
    glVertex2f(13,29);
    glVertex2f(24,35);
    glVertex2f(34,50);
    glVertex2f(37,43);
    glVertex2f(42,52);
    glVertex2f(55,40);
    glVertex2f(67,61);
    glVertex2f(77,53);
    glVertex2f(94,79);
    glVertex2f(106,54);
    glVertex2f(126,50);
    glVertex2f(139,29);
    glVertex2f(160,20);
    glVertex2f(180,0);

    glEnd();

}

void volcano()
{
    if(vVisible){
    glColor3ub(250, 69, 50); // red color for the volcano
    glBegin(GL_POLYGON);
    glVertex2f(82,62);
    glVertex2f(66,81);
    glVertex2f(82,71);
    glVertex2f(79,87);
    glVertex2f(87,78);
    glVertex2f(91,98);
    glVertex2f(100,80);
    glVertex2f(104,88);
    glVertex2f(106,76);
    glVertex2f(118,83);
    glVertex2f(102,62);
    glVertex2f(82,62);
    glEnd();
    }

}

void display()
{
    frame();
    ground1();
    ground2();
    river();
    mountain();
    volcano();
    glutSwapBuffers();

}

void init(){
    glClearColor(0, 0, 0, 1); // Set background color to white
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-20, 200, -80, 120); // Set the coordinate system
}
void update(int value) {

    vVisible = !vVisible;
	glutPostRedisplay();
	glutTimerFunc(500,update,0);
}


int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_MULTISAMPLE);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Volcano Scenario");
    init();
    glutDisplayFunc(display);
    glutTimerFunc(0, update, 0);
    glutMainLoop();
    return 0;
}


