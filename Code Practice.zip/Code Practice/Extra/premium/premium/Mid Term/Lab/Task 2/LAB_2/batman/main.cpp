#include <windows.h>
#include <GL/glut.h>

void Background_1(){
        glBegin(GL_POLYGON);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(-3.5f, -7.5f);
        glVertex2f(-8.5f, -3.5f);
        glVertex2f(-8.5f, 3.5f);
        glVertex2f(-3.5f, 7.5f);
        glVertex2f(3.5f, 7.5f);
        glVertex2f(8.5f, 3.5f);
        glVertex2f(8.5f, -3.5f);
        glVertex2f(3.5f, -7.5f);
        glEnd();
}

void Background_2(){
        glBegin(GL_POLYGON);
        glColor3f(1.0f, 0.95f, 0.0f);
        glVertex2f(-3.0f, -7.0f);
        glVertex2f(-8.0f, -3.0f);
        glVertex2f(-8.0f, 3.0f);
        glVertex2f(-3.0f, 7.0f);
        glVertex2f(3.0f, 7.0f);
        glVertex2f(8.0f, 3.0f);
        glVertex2f(8.0f, -3.0f);
        glVertex2f(3.0f, -7.0f);
        glEnd();
}

void center(){
        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(-7.0f, -2.0f);
        glVertex2f(-7.0f, 2.0f);
        glVertex2f(7.0f, 2.0f);
        glVertex2f(7.0f, -2.0f);
        glEnd();
}

void left_1(){
        glBegin(GL_POLYGON);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(-4.0f, 2.0f);
        glVertex2f(-7.0f, 2.0f);
        glVertex2f(-7.0f, 3.0f);
        glVertex2f(-6.0f, 3.0f);
        glVertex2f(-6.0f, 4.0f);
        glVertex2f(-5.0f, 4.0f);
        glVertex2f(-5.0f, 5.0f);
        glVertex2f(-4.0f, 5.0f);
        glEnd();
}

void left_2(){
        glBegin(GL_POLYGON);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(-4.0f, -2.0f);
        glVertex2f(-7.0f, -2.0f);
        glVertex2f(-7.0f, -3.0f);
        glVertex2f(-6.0f, -3.0f);
        glVertex2f(-6.0f, -4.0f);
        glVertex2f(-5.0f, -4.0f);
        glVertex2f(-5.0f, -5.0f);
        glVertex2f(-4.0f, -5.0f);
        glEnd();

}

void right_1(){
        glBegin(GL_POLYGON);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(4.0f, 2.0f);
        glVertex2f(7.0f, 2.0f);
        glVertex2f(7.0f, 3.0f);
        glVertex2f(6.0f, 3.0f);
        glVertex2f(6.0f, 4.0f);
        glVertex2f(5.0f, 4.0f);
        glVertex2f(5.0f, 5.0f);
        glVertex2f(4.0f, 5.0f);
        glEnd();
    }

void right_2(){

        glBegin(GL_POLYGON);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(4.0f, -2.0f);
        glVertex2f(7.0f, -2.0f);
        glVertex2f(7.0f, -3.0f);
        glVertex2f(6.0f, -3.0f);
        glVertex2f(6.0f, -4.0f);
        glVertex2f(5.0f, -4.0f);
        glVertex2f(5.0f, -5.0f);
        glVertex2f(4.0f, -5.0f);
        glEnd();
}

void left_3(){

        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(-3.0f, 4.30f);
        glVertex2f(-4.10f, 4.30f);
        glVertex2f(-4.10f, 5.50f);
        glVertex2f(-3.0f, 5.50f);
        glEnd();

}

void left_4(){

        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(-3.0f, -4.30f);
        glVertex2f(-4.10f, -4.30f);
        glVertex2f(-4.10f, -5.50f);
        glVertex2f(-3.0f, -5.50f);
        glEnd();
}

void right_3(){

        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(3.0f, 4.30f);
        glVertex2f(4.10f, 4.30f);
        glVertex2f(4.10f, 5.50f);
        glVertex2f(3.0f, 5.50f);
        glEnd();
    }

void right_4(){

        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(3.0f, -4.30f);
        glVertex2f(4.10f, -4.30f);
        glVertex2f(4.10f, -5.50f);
        glVertex2f(3.0f, -5.50f);
        glEnd();
        }

void head(){

        glBegin(GL_POLYGON);
        glVertex2f(-1.0f, 2.0f);
        glVertex2f(-1.0f, 5.0f);
        glVertex2f(-0.4f, 4.0f);
        glVertex2f(0.6f, 4.0f);
        glVertex2f(1.0f, 5.0f);
        glVertex2f(1.0f, 2.0f);
        glEnd();
}

void left_twin(){

        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(-3.0f, 2.0f);
        glVertex2f(-4.0f, 2.0f);
        glVertex2f(-4.0f, 3.0f);
        glVertex2f(-3.0f, 3.0f);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(-1.0f, 2.0f);
        glVertex2f(-2.0f, 2.0f);
        glVertex2f(-2.0f, 3.0f);
        glVertex2f(-1.0f, 3.0f);
        glEnd();
}

void left_twin_down(){
        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(-3.0f, -2.0f);
        glVertex2f(-4.0f, -2.0f);
        glVertex2f(-4.0f, -3.0f);
        glVertex2f(-3.0f, -3.0f);
        glEnd();
        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(-1.0f, -2.0f);
        glVertex2f(-2.0f, -2.0f);
        glVertex2f(-2.0f, -3.0f);
        glVertex2f(-1.0f, -3.0f);
        glEnd();
}

void right_twin(){
        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(3.0f, 2.0f);
        glVertex2f(4.0f, 2.0f);
        glVertex2f(4.0f, 3.0f);
        glVertex2f(3.0f, 3.0f);
        glEnd();
        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(1.0f, 2.0f);
        glVertex2f(2.0f, 2.0f);
        glVertex2f(2.0f, 3.0f);
        glVertex2f(1.0f, 3.0f);
        glEnd();

}

void right_twin_down(){
        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(3.0f, -2.0f);
        glVertex2f(4.0f, -2.0f);
        glVertex2f(4.0f, -3.0f);
        glVertex2f(3.0f, -3.0f);
        glEnd();
        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(1.0f, -2.0f);
        glVertex2f(2.0f, -2.0f);
        glVertex2f(2.0f, -3.0f);
        glVertex2f(1.0f, -3.0f);
        glEnd();

}

void bottom_right(){
        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(0.5f, -3.0f);
        glVertex2f(1.5f, -3.0f);
        glVertex2f(1.5f, -4.0f);
        glVertex2f(0.5f, -4.0f);
        glEnd();
    }

void bottom_left(){
        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);
        glVertex2f(-0.5f, -3.0f);
        glVertex2f(-1.5f, -3.0f);
        glVertex2f(-1.5f, -4.0f);
        glVertex2f(-0.5f, -4.0f);
        glEnd();
        }

void display() {
glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
glClear(GL_COLOR_BUFFER_BIT);
glOrtho(-17,17,-17,17,-17,17);
    Background_1();
    Background_2();
    center();
    left_1();
    left_2();
    left_3();
    left_4();
    right_1();
    right_2();
    right_3();
    right_4();
    head();
    left_twin();
    left_twin_down();
    right_twin();
    right_twin_down();
    bottom_left();
    bottom_right();

glFlush();

}

int main(int argc, char** argv) {

glutInit(&argc, argv);
glutInitWindowSize(430, 430);
glutCreateWindow("OpenGL Setup");
glutDisplayFunc(display);
glutMainLoop();
return 0;

}
