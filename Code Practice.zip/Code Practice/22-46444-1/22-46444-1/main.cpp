#include <iostream>
#include <GL/freeglut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <vector>
#include <utility>
#include <math.h>
using namespace std;
struct RGB
{
    int red;
    int green;
    int blue;
};

struct View
{
    string view;
    RGB skyTop;
    RGB skyBottom;
    RGB frontMountain;
    RGB rearMountain;
    RGB lightShadow;
    RGB darkShadow;
    RGB River;
    RGB ground;
    RGB houseWallShadowed;
    RGB houseWallSide;
    RGB houseRoof;
    RGB houseWindows;
    RGB houseDoor;
    RGB treeLeft;
    RGB treeRight;
    RGB treeBase;
    RGB riverMark;
    RGB groundMark;
    RGB tentRoof;
    RGB tentRoofdark;
    RGB tentFront;
    RGB tentRope;
    RGB boatSails;
    RGB boatMast;
    RGB boatBody;
};

float birdX = 0, birdY=750, birdWingY = -1, birdDirection=1;
unsigned long long lastFrameTime = 0;
float cloud2X = 1000;
vector<pair<int, int>> rainArray;

View noon = {
    "noon",                         // Name or description of the view

    // Colors for different elements of the view
    {199, 193, 141},                // skyTop: Light beige color
    {245, 207, 119},                // skyBottom: Light yellow color
    {145, 167, 102},                // frontMountain: Olive green color
    {152, 142, 103},                // rearMountain: Grayish brown color
    {194, 184, 136},                // lightShadow: Light khaki color
    {113, 153, 92},                 // darkShadow: Dark olive green color
    {204, 193, 163},                // River: Light brown color
    {100, 118, 92},                 // ground: Dark olive green color

    {68, 153, 161},                 // houseWallShadowed: Cyan color
    {255, 255, 191},                // houseWallSide: Light yellow color
    {154, 111, 44},                 // houseRoof: Brown color
    {36, 58, 63},                   // houseWindows: Dark cyan color
    {36, 58, 63},                   // houseDoor: Dark cyan color

    {59, 82, 66},                   // treeLeft: Dark green color
    {58, 92, 70},                   // treeRight: Dark green color
    {85, 38, 23},                   // treeBase: Dark brown color
    {142, 159, 141},                // riverMark: Light grayish green color
    {149, 136, 112},                // groundMark: Light brown color
};



View afternoon = {
    "afternoon",                    // Name or description of the view

    // Colors for different elements of the view
    {170, 70, 38},                  // skyTop: Warm red-orange color
    {150, 120, 49},                 // skyBottom: Muted yellow color
    {139, 71, 58},                  // frontMountain: Warm brown color
    {255, 110, 65},                 // rearMountain: Bright orange color
    {254, 127, 74},                 // lightShadow: Light orange color
    {205, 47, 63},                  // darkShadow: Deep red color
    {254, 143, 71},                 // River: Light orange color
    {154, 47, 41},                  // ground: Dark reddish-brown color

    {122, 76, 14},                  // houseWallShadowed: Dark yellow-brown color
    {182, 119, 26},                 // houseWallSide: Warm yellow color
    {53, 22, 4},                    // houseRoof: Dark brown color
    {48, 10, 0},                    // houseWindows: Very dark brown color
    {48, 10, 0},                    // houseDoor: Very dark brown color

    {115, 13, 8},                   // treeLeft: Dark red color
    {114, 37, 3},                   // treeRight: Dark reddish-brown color
    {0, 0, 0},                      // treeBase: Black color
    {186, 90, 49},                  // riverMark: Warm brown color
    {178, 52, 40},                  // groundMark: Dark red color
};


View array[2] = {noon,afternoon};
int a = 0;
View currentView = array[a];

//O1
void quad(float x1, float x2, float y1, float y2, RGB rgb, float Tx = 0, float Ty = 0, float s = 1)
{
    glColor3ub(rgb.red, rgb.green, rgb.blue);
    glBegin(GL_QUADS);
    glVertex2f(s * x1 + Tx, s * y1 + Ty);
    glVertex2f(s * x2 + Tx, s * y1 + Ty);
    glVertex2f(s * x2 + Tx, s * y2 + Ty);
    glVertex2f(s * x1 + Tx, s * y2 + Ty);
    glEnd();
}

//O2
void circle(float x, float y, float radius, float height, RGB rgb)
{
    int triangleAmount = 360;
    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(rgb.red, rgb.green, rgb.blue);
    glVertex2f(x, y); // center of circle
    for (int i = 0; i <= 360; i++)
        glVertex2f(x + (radius * cos(i * 2 * 3.1416 / triangleAmount)), y + (height * sin(i * 2 * 3.1416 / triangleAmount)));
    glEnd();
}

//O3
void quad(vector<pair<float, float>> coord, RGB rgb = {255, 255, 255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glColor3ub(rgb.red, rgb.green, rgb.blue);
    glBegin(GL_QUADS);
    for (int i = 0; i < coord.size(); i++)
        glVertex2d(Tx + s * coord[i].first, Ty + s * coord[i].second);
    glEnd();
}

//O4
void triangle(vector<pair<float, float>> coord, RGB rgb = {255, 255, 255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glColor3ub(rgb.red, rgb.green, rgb.blue);
    glBegin(GL_TRIANGLES);
    for (int i = 0; i < coord.size(); i++)
        glVertex2d(Tx + s * coord[i].first, Ty + s * coord[i].second);
    glEnd();
}

//O5
void polygon(vector<pair<float, float>> coord, RGB rgb = {255, 255, 255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glColor3ub(rgb.red, rgb.green, rgb.blue);
    glBegin(GL_POLYGON);
    for (int i = 0; i < coord.size(); i++)
        glVertex2d(Tx + s * coord[i].first, Ty + s * coord[i].second);
    glEnd();
}

//O6
void sky()
{
    glBegin(GL_QUADS);

    // Color for the bottom part of the sky
    glColor3ub(currentView.skyBottom.red, currentView.skyBottom.green, currentView.skyBottom.blue);
    glVertex2f(0, 660);             // Bottom-left vertex
    glVertex2f(1920, 660);          // Bottom-right vertex

    //Color for the top part of the sky
    glColor3ub(currentView.skyTop.red, currentView.skyTop.green, currentView.skyTop.blue);
    glVertex2f(1920, 1080);         // Top-right vertex
    glVertex2f(0, 1080);            // Top-left vertex

    glEnd();
}


//O9
void rearField() {
    //far ground
    polygon({ {0, 400}, {500, 400}, {550, 425}, {1150, 425}, {1200, 450}, {1920, 475}, {1920, 515}, {0, 515} }, currentView.ground);
}

//O10
void frontField()
{
    //near ground
    quad(0, 1920, 0, 275, currentView.ground);
}

//O11
void fieldMark()
{
    //ground marks
    polygon({{99.52, 76.46}, {128.62, 68.42}, {209.72, 58.32}, {141.62, 45.32}, {143.06, 38.93}, {165.97, 30.06}, {231.51, 16.77}, {230.18, 10.81}, {194.09, 1.88}, {4.7, 2.21}, {5.01, 211.23}, {35.76, 214.12}, {187.22, 209.79}, {136.87, 196.8}, {69.51, 167.05}, {141.41, 143.39}, {141.62, 121.11}, {113.14, 119.46}}, currentView.groundMark);
    polygon({{299.17, 75.57}, {299.17, 71.6}, {390.36, 67.62}, {340.29, 60}, {300.83, 59}, {227.88, 60.99}, {235.18, 66.62}, {221.58, 73.58}, {188.75, 76.23}, {189.42, 85.84}, {302.82, 86.18}, {413.24, 81.54}}, currentView.groundMark);
    polygon({{474.64, 10.6}, {502.9, 0.59}, {359.9, 0.73}, {325.97, 6.38}, {362.62, 9.94}, {442.64, 14.13}, {408.08, 17.26}, {296.51, 21.85}, {461.09, 31.68}, {549.82, 28.35}, {576.23, 24.71}, {543.15, 17.91}}, currentView.groundMark);
    polygon({{807.17, 49.91}, {828.74, 48.21}, {863.17, 46.81}, {886.27, 44.18}, {859.23, 39.89}, {835.78, 38.33}, {805.44, 38.3}, {763.08, 39.98}, {782.46, 46.76}, {750.77, 50.35}, {730.82, 53.16}, {713.48, 56.93}, {730.22, 59.69}, {777.45, 61.56}, {809.1, 61.08}, {892.17, 56.96}, {909.43, 55.71}, {886.31, 53.26}, {829.61, 52.31}, {813.73, 51.01}}, currentView.groundMark);
    polygon({{1305, 125.94}, {1372.99, 122.19}, {1401.47, 118.17}, {1339.11, 111.54}, {1247.54, 113.13}, {1275.21, 122.41}, {1214.34, 129.13}, {1186.08, 134.46}, {1213.95, 138.61}, {1293.05, 140.77}, {1431.68, 133.45}, {1396.7, 129.89}, {1316.07, 127.72}}, currentView.groundMark);
    polygon({{1272.2, 69.89}, {1287.07, 64.06}, {1302.94, 59.43}, {1220.25, 56.5}, {1157.94, 60.53}, {1122.91, 65.33}, {1161.07, 69.36}, {1239.53, 73.27}, {1226.92, 75.41}, {1129.75, 78.32}, {1093.94, 82.56}, {1251.64, 90.19}, {1341.11, 88.15}, {1373.66, 83.54}, {1314.39, 73.7}}, currentView.groundMark);
}

//O12
void river1()
{
    quad(0, 1920, 275, 475, currentView.River);
}

//O13
void riverWave()
{
    //river wave marks
    polygon({{376.19, 358.48}, {419.81, 358.58}, {576.24, 359.22}, {556.84, 357.92}, {535.97, 357.27}, {324.01, 351.07}, {312.76, 352.21}, {305.75, 354.33}, {302.65, 356.45}, {303.81, 359.22}, {372.32, 359.29}}, currentView.riverMark);
    polygon({{371.56, 326.76}, {401.72, 325.62}, {471.68, 328.03}, {532.49, 327.62}, {544.1, 325.67}, {551.81, 324.02}, {557.67, 319.81}, {385.19, 315.65}, {342.03, 314.88}, {338.49, 314.17}, {269.1, 314.3}, {196.6, 317.61}, {129.52, 321.47}, {4.94, 321.47}, {5.01, 326.48}, {9.06, 327.83}, {349.4, 330.36}, {366.78, 329.43}}, currentView.riverMark);
    polygon({{722.99, 303.15}, {738.56, 302.14}, {801.07, 303.5}, {864.44, 304.45}, {891.52, 302.76}, {904.53, 299.59}, {907.92, 296.42}, {765.56, 292.61}, {613.27, 290.67}, {552.92, 293.89}, {464.39, 298.62}, {346.93, 298.56}, {346.81, 299.81}, {359.93, 304.18}, {606.62, 304.34}, {649.1, 306.2}, {717.74, 305.86}}, currentView.riverMark);
    polygon({{662.01, 353.46}, {742.91, 353}, {934.56, 353.67}, {898.04, 351.66}, {859.69, 350.73}, {803.1, 348.92}, {760.74, 347.52}, {682.15, 345.25}, {671.42, 346.21}, {662.64, 348.75}, {660.49, 351.4}}, currentView.riverMark);
    polygon({{830.6, 318.74}, {960.09, 319.18}, {1094.99, 315.51}, {1067.92, 307.21}, {933.51, 308.38}, {869.89, 309.96}, {847.8, 310.51}, {835.44, 312.53}, {829.84, 315.02}}, currentView.riverMark);
    polygon({{1514.12, 326.91}, {1685.36, 325.75}, {1697.7, 321.36}, {1698.59, 319.56}, {1391.89, 314.8}, {1262.23, 321.76}, {1230.33, 321.98}, {1219.42, 321.44}, {1203.92, 321.39}, {1154.4, 321.22}, {1137.28, 322.11}, {1137.15, 323.41}, {1150.62, 327.86}, {1509.18, 329.36}}, currentView.riverMark);
    polygon({{1444.95, 359.54}, {1717.25, 359.72}, {1677.3, 357.73}, {1594.59, 354.74}, {1474.09, 351.21}, {1457, 351.99}, {1445.33, 354.76}, {1443.81, 357.06}}, currentView.riverMark);
    polygon({{1864.31, 303.37}, {1915.04, 302.51}, {1914.93, 292.75}, {1748.05, 290.93}, {1604.49, 298.77}, {1553.8, 297.75}, {1487.91, 298.06}, {1500.63, 304.42}, {1748.27, 304.48}, {1824.69, 306.86}, {1852.49, 307.01}, {1860.58, 305.37}}, currentView.riverMark);
    polygon({{1803.1, 353.47}, {1801.78, 350.48}, {1810.2, 346.56}, {1827.13, 344.56}, {1914.52, 347.29}, {1914.7, 352.56}}, currentView.riverMark);
    polygon({{1187.36, 270.55}, {1185.55, 268.53}, {1187.71, 266.2}, {1196.22, 263.62}, {1208.8, 262.16}, {1280.47, 264.54}, {1460.98, 271.41}}, currentView.riverMark);
}


//O15
void rearMountain()
{
    polygon({{387, 500}, {387, 760}, {348.32, 765.88}, {320.46, 774.31}, {299.96, 789.06}, {286.54, 781.83}, {243.2, 807.31}, {216.28, 788.02}, {206.29, 788.98}, {149.44, 766.41}, {116.31, 735.41}, {80.72, 735.49}, {42.76, 721.31}, {0, 712.6}, {0, 500}}, currentView.rearMountain);
    polygon({{690.42, 519.21}, {690.42, 757.24}, {709.64, 766.25}, {728.84, 762.53}, {745.91, 779.31}, {774.19, 797.69}, {787.32, 790.72}, {808.37, 807.38}, {863.74, 769.09}, {876.16, 776.44}, {901.02, 771.37}, {916.09, 757.99}, {945.28, 782.72}, {1002.54, 737.36}, {1024.48, 745.68}, {1024.48, 745.68}, {1084.4, 712.8}, {1096.1, 718.64}, {1125.06, 692.17}, {1166.05, 675.09}, {1195.96, 677.25}, {1230.89, 688.87}, {1267.07, 688.85}, {1300.48, 715.54}, {1357.64, 735.28}, {1366.68, 734.21}, {1393.75, 751.33}, {1437.43, 729.19}, {1450.75, 735.32}, {1471.2, 722.3}, {1498.42, 715.01}, {1537.89, 710.47}, {1537.89, 515.63}}, currentView.rearMountain);
    polygon({{1841.53, 515.63}, {1841.53, 707.41}, {1860.76, 715.26}, {1879.12, 712.43}, {1920, 736.81}, {1920, 515.63}}, currentView.rearMountain);
}

//16
void rearMountainShadow()
{
    //shadow-light rear mountain
    polygon({{11.49, 678.1}, {19.58, 706.16}, {54.84, 710.9}, {80.56, 730.61}, {96.73, 730.61}, {79.28, 693.96}, {41.78, 693.96}}, currentView.lightShadow);
    polygon({{122.62, 730.92}, {138.09, 710.48}, {121.89, 692.85}, {95.14, 680.23}, {116.84, 700.82}}, currentView.lightShadow);
    polygon({{171.57, 733.51}, {181.76, 751.26}, {204.37, 760}, {222.91, 783.13}, {241.67, 798.35}, {235.72, 782.12}, {216.45, 760.23}, {209.28, 749.34}, {190.2, 742.87}}, currentView.lightShadow);
    polygon({{254.59, 742.59}, {276.38, 773.33}, {298.97, 781.39}, {340.33, 753.78}, {305.12, 761.74}, {278.5, 753.88}}, currentView.lightShadow);
    polygon({{722.66, 754.34}, {737.85, 760.17}, {746.01, 778.78}, {772.29, 787.05}, {774.3, 791.78}, {776.62, 791.78}, {780.94, 786.75}, {773.8, 776.79}, {743.9, 754.06}}, currentView.lightShadow);
    polygon({{748.31, 750.64}, {773.17, 766.73}, {787.36, 783.03}, {805.08, 792.08}, {810.42, 803.68}, {812.94, 786.07}, {792.51, 775.31}, {773.28, 753.79}}, currentView.lightShadow);
    polygon({{799.01, 733.56}, {824.29, 749.65}, {829.6, 761.87}, {818.49, 791.95}, {839.74, 776.03}, {847.63, 761.87}, {844.08, 748.68}, {823.8, 733.88}, {810.12, 709.75}}, currentView.lightShadow);
    polygon({{826.87, 726.14}, {855.2, 744.8}, {860.19, 755.25}, {868.56, 766.51}, {882.41, 773.11}, {886.75, 767.8}, {884.02, 760.08}, {865.99, 744.15}}, currentView.lightShadow);
    polygon({{887.55, 726.72}, {900.81, 739.31}, {928.96, 745.57}, {944.45, 773.63}, {944.45, 754.45}, {955.21, 735.99}, {910.93, 725.84}, {888.55, 708.56}}, currentView.lightShadow);
    polygon({{953.05, 765.26}, {978.86, 749}, {996.53, 724.32}, {978.66, 716.79}, {962.69, 752.21}}, currentView.lightShadow);
    polygon({{1024.67, 741.68}, {1031.81, 733.2}, {1075.98, 706.34}, {1092.04, 706.34}, {1075.48, 686.78}, {1080.7, 699.82}, {1061.13, 708.74}, {1049.29, 698.62}, {1040.96, 673.75}, {1048.7, 708.47}, {1043.79, 719.68}, {1026.57, 728.28}}, currentView.lightShadow);
    polygon({{1161.99, 639.32}, {1168.97, 662.37}, {1204.85, 667.32}, {1231.12, 684.63}, {1247.26, 684.63}, {1229.74, 652.72}, {1191.9, 652.72}}, currentView.lightShadow);
    polygon({{1246.26, 641.17}, {1267.16, 658.06}, {1272.76, 684.83}, {1288.76, 667.15}, {1272.76, 651.96}}, currentView.lightShadow);
    polygon({{1321.54, 686.76}, {1331.03, 701.6}, {1354.75, 709.58}, {1371.94, 728.45}, {1392.22, 743.33}, {1386.03, 728.76}, {1368.55, 711.68}, {1359.44, 700.66}, {1339.93, 695.07}}, currentView.lightShadow);
    polygon({{1404.71, 694.4}, {1426.86, 721.35}, {1449.47, 728.41}, {1490.54, 704.48}, {1455.47, 711.37}, {1429.99, 704.98}}, currentView.lightShadow);
    polygon({{1872.1, 705.02}, {1888.57, 709.91}, {1894.26, 721.28}, {1899.86, 724.97}, {1914.33, 728.26}, {1914.33, 718.19}, {1894.46, 704.82}}, currentView.lightShadow);
}

//O17
void frontMountain()
{
    polygon({{1166.00, 500.00}, {1166.00, 535.11}, {1205.15, 550.08}, {1238.54, 603.29}, {1398.15, 667.96}, {1436.34, 647.9}, {1460.13, 671.01}, {1525.59, 691.51}, {1532.36, 708.08}, {1568.29, 729.59}, {1589.46, 750.52}, {1674.12, 807.22}, {1718.64, 764.92}, {1734.57, 770.37}, {1760.1, 747.91}, {1782.62, 753.8}, {1829.14, 722.66}, {1850.61, 696.52}, {1859.94, 702.7}, {1920, 685.85}, {1920, 515.63}}, currentView.frontMountain);
    polygon({{0, 500}, {2.25, 551.5}, {38.98, 551.5}, {88.79, 636.1}, {248.5, 710.75}, {285.99, 688.18}, {309.44, 714.25}, {374.34, 737.76}, {382.35, 757.46}, {416.33, 781.97}, {438.72, 806.81}, {523.28, 872.26}, {569.27, 823.59}, {584.07, 829.74}, {609.17, 804.24}, {631.7, 810.58}, {678.52, 774.51}, {700.18, 743.9}, {709.57, 751.36}, {788.14, 724.27}, {811.41, 701.83}, {826.72, 711.39}, {828.6, 710.54}, {829.72, 711.5}, {831.99, 709.63}, {879.22, 698.09}, {920.12, 686.66}, {954.98, 674.09}, {965.89, 668.04}, {970.37, 664.47}, {970.37, 662.34}, {984.1, 650.66}, {1155.36, 539.05}, {1155.36, 531.11}, {1166.00, 535.11}, {1166.00, 500.00}}, currentView.frontMountain);
}


//O19
void tree(float Tx, float Ty, float s = 1, RGB treeleft = {2, 110, 123}, RGB treeRight = {2, 148, 138}, RGB treeBase = {70, 38, 17})
{
    //left
    polygon({{Tx + s * 0, Ty + s * 48.57}, {Tx + s * -39.01, Ty + s * 48.57}, {Tx + s * -34.88, Ty + s * 75.17}, {Tx + s * -24.92, Ty + s * 61.88}, {Tx + s * -33.42, Ty + s * 84.56}, {Tx + s * -31.06, Ty + s * 99.78}, {Tx + s * -15.47, Ty + s * 66.84}, {Tx + s * -30.11, Ty + s * 105.9}, {Tx + s * -27.82, Ty + s * 120.62}, {Tx + s * -19.83, Ty + s * 103.74}, {Tx + s * -27.33, Ty + s * 123.76}, {Tx + s * -19.55, Ty + s * 173.84}, {Tx + s * -0.71, Ty + s * 149.68}, {Tx + s * -16.68, Ty + s * 192.3}, {Tx + s * -12.7, Ty + s * 217.93}, {Tx + s * -5.3, Ty + s * 208.05}, {Tx + s * -11.62, Ty + s * 224.91}, {Tx + s * -9.11, Ty + s * 241.04}, {Tx + s * -0.71, Ty + s * 226}, {Tx + s * -8.3, Ty + s * 246.25}, {Tx + s * 0, Ty + s * 299.76}}, treeleft);
    //right
    polygon({{Tx + s * 0, Ty + s * 48.57}, {Tx + s * 39.04, Ty + s * 48.57}, {Tx + s * 31.32, Ty + s * 98.28}, {Tx + s * 12.13, Ty + s * 79.1}, {Tx + s * 28.64, Ty + s * 115.48}, {Tx + s * 22.52, Ty + s * 154.9}, {Tx + s * 12.13, Ty + s * 144.51}, {Tx + s * 21.93, Ty + s * 158.73}, {Tx + s * 14.78, Ty + s * 204.74}, {Tx + s * 7.39, Ty + s * 197.36}, {Tx + s * 13.75, Ty + s * 211.36}, {Tx + s * 0, Ty + s * 299.76}}, treeRight);
    //base
    triangle({{Tx + s * 4.59, Ty + s * -0.03}, {Tx + s * -0.71, Ty + s * 219.82}, {Tx + s * -10.07, Ty + s * 0.02}, {Tx + s * -0.89, Ty + s * 46.87}, {Tx + s * -25.93, Ty + s * 98.64}, {Tx + s * -0.89, Ty + s * 61.32}, {Tx + s * -0.71, Ty + s * 64.41}, {Tx + s * 16.71, Ty + s * 100.43}, {Tx + s * -0.71, Ty + s * 74.46}, {Tx + s * -0.71, Ty + s * 86.87}, {Tx + s * 16.71, Ty + s * 122.89}, {Tx + s * -0.89, Ty + s * 96.67}, {Tx + s * -0.89, Ty + s * 109.64}, {Tx + s * -18.48, Ty + s * 146.01}, {Tx + s * -0.89, Ty + s * 119.79}, {Tx + s * -0.71, Ty + s * 148.71}, {Tx + s * 11.97, Ty + s * 175.2}, {Tx + s * -0.71, Ty + s * 156.29}, {Tx + s * -0.89, Ty + s * 169.09}, {Tx + s * -12.39, Ty + s * 192.88}, {Tx + s * -0.89, Ty + s * 175.73}, {Tx + s * -0.89, Ty + s * 132.44}, {Tx + s * -12.39, Ty + s * 156.22}, {Tx + s * -0.71, Ty + s * 138.82}}, treeBase);
}


//O24
void cloud2(float Tx, float Ty, float s)
{
    //cloud
    circle(Tx + s * 13, Ty + s * 16, 7, 7, {255, 255, 255});
    circle(Tx + s * 24, Ty + s * 24, 9, 9, {255, 255, 255});
    circle(Tx + s * 40, Ty + s * 32, 12, 12, {255, 255, 255});
    circle(Tx + s * 54, Ty + s * 36, 7, 7, {255, 255, 255});
    circle(Tx + s * 74, Ty + s * 40, 16, 16, {255, 255, 255});
    circle(Tx + s * 95, Ty + s * 40, 10, 10, {255, 255, 255});
    circle(Tx + s * 108, Ty + s * 34, 6, 6, {255, 255, 255});
    circle(Tx + s * 122, Ty + s * 31, 10, 10, {255, 255, 255});
    circle(Tx + s * 132, Ty + s * 25, 10, 10, {255, 255, 255});
    circle(Tx + s * 144, Ty + s * 16, 6, 6, {255, 255, 255});
    quad({{12, 18}, {146, 18}, {146, 11}, {11, 10}}, {255, 255, 255}, Tx, Ty, s);
    quad({{20, 32}, {138, 32}, {138, 17}, {20, 17}}, {255, 255, 255}, Tx, Ty, s);
}



//O27
void house2(float x, float y, int m = 1, RGB houseWallShadowed = {15, 151, 161}, RGB houseWallSide = {255, 254, 255}, RGB houseRoof = {255, 201, 84}, RGB houseWindows = {24, 105, 126})
{
    polygon({{x + m * 0, y + 0}, {x + m * 40.07, y + 0}, {x + m * 40.14, y + 26.27}, {x + m * 19.84, y + 48.1}, {x + m * -0.04, y + 26.06}}, houseWallShadowed);

    //sidewall
    quad({{x + m * 40.07, y + 0}, {x + m * 141.26, y + 0}, {x + m * 141.06, y + 26.27}, {x + m * 40.14, y + 26.27}}, houseWallSide);

    //roof
    quad({{x + m * 19.84, y + 48.1}, {x + m * 40.14, y + 26.27}, {x + m * 141.06, y + 26.27}, {x + m * 121.52, y + 48.26}}, houseRoof);

    //window
    quad({{x + m * 6.65, y + 7.08}, {x + m * 10.83, y + 7.08}, {x + m * 10.83, y + 19.13}, {x + m * 6.65, y + 19.13}, {x + m * 17.82, y + 7.15}, {x + m * 22, y + 7.15}, {x + m * 22, y + 19.2}, {x + m * 17.82, y + 19.2}, {x + m * 29.36, y + 6.98}, {x + m * 33.54, y + 6.98}, {x + m * 33.54, y + 19.03}, {x + m * 29.36, y + 19.03}, {x + m * 46.23, y + 14.96}, {x + m * 50.83, y + 14.96}, {x + m * 50.83, y + 19.01}, {x + m * 46.23, y + 19.01}, {x + m * 60.35, y + 15.09}, {x + m * 64.94, y + 15.09}, {x + m * 64.94, y + 19.13}, {x + m * 60.35, y + 19.13}, {x + m * 74.39, y + 14.88}, {x + m * 78.99, y + 14.88}, {x + m * 78.99, y + 18.92}, {x + m * 74.39, y + 18.92}, {x + m * 88.43, y + 14.88}, {x + m * 93.03, y + 14.88}, {x + m * 93.03, y + 18.92}, {x + m * 88.43, y + 18.92}, {x + m * 102.53, y + 15.09}, {x + m * 107.12, y + 15.09}, {x + m * 107.12, y + 19.13}, {x + m * 102.53, y + 19.13}, {x + m * 116.46, y + 14.91}, {x + m * 121.06, y + 14.91}, {x + m * 121.06, y + 18.96}, {x + m * 116.46, y + 18.96}, {x + m * 130.73, y + 14.91}, {x + m * 135.33, y + 14.91}, {x + m * 135.33, y + 18.95}, {x + m * 130.73, y + 18.95}}, houseWindows);
}


//O30
void bird(float Tx, float Ty, float direction, float birdWingY, RGB rgb = {0,0,0})
{
    polygon({{Tx + direction * 28.65, Ty + 2.99}, {Tx + direction * 31.98, Ty + 1.74}, {Tx + direction * 31.6, Ty + 0.23}, {Tx + direction * 31.93, Ty + -1.29}, {Tx + direction * 30.43, Ty + -0.38}, {Tx + direction * 28.77, Ty + -1.12}, {Tx + direction * 24.29, Ty + -4.59}, {Tx + direction * 16.47, Ty + -5.28}, {Tx + direction * 10.7, Ty + -4.96}, {Tx + direction * 2.95, Ty + -10.29}, {Tx + direction * 8.55, Ty + -3.22}, {Tx + direction * 0.18, Ty + 1.29}, {Tx + direction * 9.57, Ty + -0.31}, {Tx + direction * 11.02, Ty + 0.27}, {Tx + direction * 22.82, Ty + 1.86}, {Tx + direction * 28.65, Ty + 2.99}}, {rgb.red, rgb.green, rgb.blue});
    polygon({{Tx + direction * 22.82, Ty + birdWingY * 1.86}, {Tx + direction * 23.38, Ty + birdWingY * 8.57}, {Tx + direction * 9.98, Ty + birdWingY * 25.45}, {Tx + direction * 11.02, Ty + birdWingY * 0.27}}, {rgb.red, rgb.green, rgb.blue});
}

int random(int low, int high)
{
    int r = rand();
    r = r % (high-low+1);
    return r+low;
}

//O33
void rain(int x1, int x2, int y1, int y2)
{
    if (rainArray.size() == 0)
    {
        for (int i = 0; i < 1000; i++)  //Rain drops you want
        {
            int x = random(x1, x2);
            int y = random(y1, y2);
            rainArray.push_back({x, y});
        }
    }

    // Adjust the line width to make raindrops thinner or thicker
    glLineWidth(1.5f);

    glColor3ub(173, 216, 230); // Light blue color for rain
    glBegin(GL_LINES);
    for (int i = 0; i < rainArray.size(); i++)
    {
        glVertex2i(rainArray[i].first, rainArray[i].second);
        glVertex2i(rainArray[i].first, rainArray[i].second -32);
    }
    glEnd();
}


void display()
{
    sky();
    rearMountain();
    rearMountainShadow();
    frontMountain();
    //clouds
    cloud2(cloud2X, 950, 1);

    //birds
    bird(birdX+20, birdY, birdDirection, birdWingY);
    bird(birdX, birdY-20, birdDirection, birdWingY);
    bird(birdX-10, birdY-35, birdDirection, birdWingY);
    bird(birdX-20, birdY+15, birdDirection, birdWingY);
    bird(birdX-20, birdY-55, birdDirection, birdWingY);
    bird(birdX-15, birdY-25, birdDirection, birdWingY);

    river1();
    riverWave();

    rearField();
    tree(1400,500,0.50,currentView.treeLeft,currentView.treeRight,currentView.treeBase);

    //house
    house2(530, 420, 1, currentView.houseWallShadowed, currentView.houseWallSide, currentView.houseRoof, currentView.houseWindows);
    house2(1090, 450, 1, currentView.houseWallShadowed, currentView.houseWallSide, currentView.houseRoof, currentView.houseWindows);
    house2(1500, 465, -1, currentView.houseWallShadowed, currentView.houseWallSide, currentView.houseRoof, currentView.houseWindows);


    frontField();
    house2(1120, 200, 1.02, currentView.houseWallShadowed, currentView.houseWallSide, currentView.houseRoof, currentView.houseWindows);
    house2(950, 150, -1.02, currentView.houseWallShadowed, currentView.houseWallSide, currentView.houseRoof, currentView.houseWindows);
    house2(400, 180, 1, currentView.houseWallShadowed, currentView.houseWallSide, currentView.houseRoof, currentView.houseWindows);



    fieldMark();

    tree(100,200,1.50,currentView.treeLeft,currentView.treeRight,currentView.treeBase);
    tree(200,450,1,currentView.treeLeft,currentView.treeRight,currentView.treeBase);
    tree(300,200,1,currentView.treeLeft,currentView.treeRight,currentView.treeBase);
    tree(720,200,1.25,currentView.treeLeft,currentView.treeRight,currentView.treeBase);
    tree(230,100,0.80,currentView.treeLeft,currentView.treeRight,currentView.treeBase);
    tree(1530,500,0.50,currentView.treeLeft,currentView.treeRight,currentView.treeBase);
    tree(1500,500,0.50,currentView.treeLeft,currentView.treeRight,currentView.treeBase);
    tree(1800,500,1.015,currentView.treeLeft,currentView.treeRight,currentView.treeBase);
    tree(1800,100,1,currentView.treeLeft,currentView.treeRight,currentView.treeBase);
    tree(1700,180,0.90,currentView.treeLeft,currentView.treeRight,currentView.treeBase);
    tree(1600,120,1.25,currentView.treeLeft,currentView.treeRight,currentView.treeBase);


    if (currentView.view == "noon")
        rain(0, 1920, 0, 1080);
    //glFlush();
    glutSwapBuffers();

}

//A1
void birdAnimation()
{
    // Bird's speed
    birdX += 6 * birdDirection;

    // Bird's wing movement
    birdWingY += 0.3;

    // If the wing movement exceeds 1 or goes below -1, reset it
    if (birdWingY > 1) birdWingY = -1;

    // If the bird goes beyond the right boundary of the scene, change its direction to move left
    if (birdX > 3000) birdDirection = -1;

    // If the bird goes beyond the left boundary of the scene, change its direction to move right
    if (birdX < -600) birdDirection = 1;
}


//A2
void cloudAnimation()
{
    // Cloud speed
    cloud2X += 2;

    // If the cloud goes beyond the right boundary of the scene, reset its position to the left side
    if (cloud2X > 1920)
        cloud2X = -144; // Reset position to the left side of the screen
}



//A7
void rainAnimation()
{
    // Raindrop positions
    for (auto &drop : rainArray)
    {
        // Rain drop speed
        drop.second -= 14;

        // If the raindrop goes above the top boundary of the screen, reset its position to a random location at the top
        if (drop.second < 0)
        {
            drop.first = random(0, 1800); // Random x-coordinate within the scene width
            drop.second = 1080;            // Reset y-coordinate to the bottom of the screen
        }
    }
}


void animation()
{
    // Set the frame time to achieve 60 frames per second (approximately 16.67 milliseconds per frame)
    float frameTime = 1000 / 60.0;

    // Get the current time
    float currentTime = GetTickCount();

    // If enough time has passed since the last frame update
    if (currentTime - lastFrameTime >= frameTime)
    {
        // Update the last frame time to the current time
        lastFrameTime = currentTime;

        // Update the animation elements
        birdAnimation();
        cloudAnimation();
        rainAnimation();
    }

    // Trigger a redraw of the scene
    glutPostRedisplay();
}


void keyboard(int key, int x, int y)
{
    switch (key)
    {
    case GLUT_KEY_LEFT:
        a--;
        a = a % 2;
        if(a<0) a=1;
        currentView = array[a];
        glutPostRedisplay();
        break;
    case GLUT_KEY_RIGHT:
        a++;
        a = a % 2;
        if(a<0) a=1;
        currentView = array[a];
        glutPostRedisplay();
        break;
    case GLUT_KEY_UP:
        a++;
        a = a % 2;
        if(a<0) a=1;
        currentView = array[a];
        glutPostRedisplay();
        break;
    case GLUT_KEY_DOWN:
        a--;
        a = a % 2;
        if(a<0) a=1;
        currentView = array[a];
        glutPostRedisplay();
        break;
    default:
        break;
    }
}

void init(void)
{
    glClearColor(0.0F, 0.0F, 0.0F, 1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, 1920, 0, 1080);
}
int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_MULTISAMPLE);
    glutInitWindowPosition(0, 0);
    glutInitWindowSize(1920, 1080);
    glutCreateWindow("Mountain View");
    glutSpecialFunc(keyboard);
    init();
    glutDisplayFunc(display);
    glutIdleFunc(animation);
    glutMainLoop();
}
